import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import java.util.Stack;

class Q1a {
    public static void main(String[] args) {
        System.out.println("Please enter the puzzle, each digit followed by a space:");
        int[] puzzle = new int[9];
        Scanner scanner = new Scanner(System.in);
        for (int i = 0; i<puzzle.length;i++){
            int j = scanner.nextInt();
            puzzle[i] = j;
        }
        Node initNode = new Node(puzzle);
        System.out.println("Entered puzzle is:");
        initNode.PrintPuzzle();
        System.out.println("Finding solution now");
        Uninformed uni = new Uninformed();
        ArrayList<Node> solution = uni.IDS(initNode);
        if(solution == null){
            System.out.println("Checked over 1 million elements");
        }
        else if(solution.size()>0){
            Collections.reverse(solution);
            System.out.println("Goal Found and now tracing its path...");
            for(int i=0;i<solution.size();i++){
                solution.get(i).PrintPuzzle();
            }
            System.out.println("Depth = "+ (solution.size()-1));
        }
        else{
            System.out.println("No path found till 1000000 depth");
        }
    }
}

class Uninformed {
    public Uninformed(){
    }
    int count = 0;
    ArrayList<Node> visited = new ArrayList<Node>();

    public ArrayList<Node> IDS(Node root){
        ArrayList<Node> PathToSolution = new ArrayList<Node>();
        for (int i = 0 ; i<Integer.MAX_VALUE; i++){
            System.out.println("Checking at DEPTH: "+(i));
            count = 0;
            Node goal = DLS2(root,i);
            if(count>1000000){
                return null;
            }
            if (goal!= null){
                if(goal.Goal()){
                    PathTrace(PathToSolution, goal);
                    break;
                }
            }
        }
        System.out.println(count);
        return PathToSolution;
    }
    public Node DLS(Node root, int depth){
        if(count>100000){
            return null;
        }
        if (depth==0){
            return null;
        }
        if(root.Goal()){
            return root;
        }
        else if(depth>0){
            root.ExpandMove();
            count++;
            for (int i =0;i<root.children.size();i++){
                Node currChild = root.children.get(i);
//                boolean abc = false;
//                for (int j = 0;j<visited.size();j++){
//                    abc = Arrays.equals(visited.get(j).puzzle,currChild.puzzle);
//                    if(abc){
//                        break;
//                    }
//                }
//                if(!abc)
                {
                    count++;
//                    visited.add(currChild);
//                    currChild.PrintPuzzle();
                    Node goalChild = DLS(currChild,depth-1);
                    if(goalChild != null){
                        if(goalChild.Goal()){
                            return goalChild;
                        }
                    }
                }
            }
        }
        return null;
    }
    public Node DLS2(Node root, int max_depth){
        if(max_depth==0){
            return null;
        }
        Stack<Node> stack = new Stack<Node>();
        root.depth = 0;
        stack.push(root);
//        visited.clear();
        while(!stack.isEmpty()){
            Node curr = stack.pop();
            if(count>1000000){
                return null;
            }
//            boolean isVisited = false;
//            for (int j = 0;j<visited.size();j++){
//                isVisited = Arrays.equals(visited.get(j).puzzle,curr.puzzle);
//                if(isVisited){
//                    break;
//                }
//            }
//            if(isVisited){
//                continue;
//            }
            if(curr.Goal()){
                return curr;
            }
            else{
                if(curr.children.size()<=0){
                    curr.ExpandMove();
                }
                count++;
//                visited.add(curr);
                for (int i = curr.children.size()-1; i>=0;i--){
                    Node currChild = curr.children.get(i);
                    if(currChild.depth==0){
                        currChild.depth = currChild.parent.depth + 1;
                    }
                    if(currChild.depth>max_depth){
                        break;
                    }
                    stack.push(currChild);
                }
            }
        }
        return null;
    }
//    public ArrayList<Node> BFS(Node root){
//        ArrayList<Node> PathToSolution = new ArrayList<Node>();
//        ArrayList<Node> OpenList = new ArrayList<Node>();
//        ArrayList<Node> CloseList = new ArrayList<Node>();
//        OpenList.add(root);
//        boolean goalFound = false;
//        while(OpenList.size()>0 && !goalFound){
//            Node currNode = OpenList.get(0);
//            CloseList.add(currNode);
//            OpenList.remove(0);
//            currNode.ExpandMove();
////            currNode.PrintPuzzle();
//            for (int i =0;i<currNode.children.size();i++){
//                Node currChild = currNode.children.get(i);
//                if(currChild.Goal()){
//                    goalFound = true;
//                    PathTrace(PathToSolution, currChild);
//                }
//                if(!Contains(OpenList,currChild) && !Contains(CloseList,currChild)){
//                    OpenList.add(currChild);
//                }
//            }
//        }
//        return PathToSolution;
//    }
    public void PathTrace(ArrayList<Node> path, Node n){
        Node current = n;
        path.add(current);
        while(current.parent != null){
            current = current.parent;
            path.add(current);
        }
    }
    public static boolean Contains(ArrayList<Node> list, Node c){
        boolean contains = false;
        for (int i =0 ; i< list.size();i++){
            if(list.get(i).isSamePuzzle(c.puzzle)){
                contains = true;
            }
        }
        return  contains;
    }
}
class Node {
    public ArrayList<Node> children = new ArrayList<>();
    public Node parent;
    public int[] puzzle = new int[9];
    public int x = 0;
    public int col = 3;
    public int depth;
    public int heuristic;
    public Node(int[] p){
        for( int i = 0; i<puzzle.length;i++){
            this.puzzle[i] = p[i];
        }
    }
    public boolean Goal(){
        boolean isGoal = true;
        for (int i = 0; i<puzzle.length;i++){
            if(i != puzzle[i])
            {
                isGoal = false;
                break;
            }
        }
        return isGoal;
    }
    public void ExpandMove(){
        for(int i = 0;i<puzzle.length;i++){
            if(puzzle[i]==0){
                x=i;
            }
        }
        MoveRight(puzzle,x);
        MoveLeft(puzzle,x);
        MoveDown(puzzle,x);
        MoveUp(puzzle,x);
    }
    public void MoveRight(int[] p, int i){
        if(i%col<col-1){
            int [] pc = p.clone();
            int temp = pc[i+1];
            pc [i+1] = pc[i];
            pc[i] = temp;
            Node child = new Node(pc);
            children.add(child);
            child.parent = this;
        }
    }
    public void MoveLeft(int[] p, int i){
        if(i%col>0){
            int [] pc = p.clone();
            int temp = pc[i-1];
            pc [i-1] = pc[i];
            pc[i] = temp;
            Node child = new Node(pc);
            children.add(child);
            child.parent = this;
        }

    }
    public void MoveUp(int[] p, int i){
        if(i-col>=0){
            int [] pc = p.clone();
            int temp = pc[i-3];
            pc [i-3] = pc[i];
            pc[i] = temp;
            Node child = new Node(pc);
            children.add(child);
            child.parent = this;
        }
    }
    public void MoveDown(int[] p, int i){
        if(i+col<puzzle.length){
            int [] pc = p.clone();
            int temp = pc[i+3];
            pc [i+3] = pc[i];
            pc[i] = temp;
            Node child = new Node(pc);
            children.add(child);
            child.parent = this;
        }
    }
    public void PrintPuzzle(){
        int m = 0;
        for (int i =0;i<col;i++){
            for(int j = 0; j<col;j++){
                System.out.print(puzzle[m]);
                m++;
            }
            System.out.println();
        }
        System.out.println();
    }
    public boolean isSamePuzzle(int[] p){
        boolean samePuz = true;
        for(int i =0; i<p.length;i++){
            if(puzzle[i]!=p[i]){
                samePuz = false;
            }
        }
        return samePuz;
    }
}



