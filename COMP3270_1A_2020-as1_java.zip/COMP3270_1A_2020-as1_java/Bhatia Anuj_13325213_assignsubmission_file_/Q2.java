import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class Q2 {
    public static void main(String[] args) {
        int[] puzzle = {
                3,3,1
        };

        State initNode = new State(puzzle);
        Uninformed uni = new Uninformed();
        ArrayList<State> solution = uni.BFS(initNode);
        if(solution == null){
            System.out.println("No Path found");
        }
        else if(solution.size()>0){
            Collections.reverse(solution);
            System.out.println("We are able to shift them and here is how: ");
            System.out.println("Missionaries(Right), Cannibals(Right), Boat Position(Right(1), Left(0)), Missionaries(Left), Cannibals(Left)");
            for(int i =0;i<solution.size();i++){
                solution.get(i).PrintState();
                if(i != solution.size()-1){
                    System.out.println("    |    ");
                }
            }
            System.out.println("The number of moves: "+ (solution.size()-1));
        }
        else{
            System.out.println("No path found");
        }
    }
}
class State {
    public ArrayList<State> children = new ArrayList<>();
    public State parent;
    public int[] position = new int[3];
    public State(int[] p){
        for( int i = 0; i<position.length;i++){
            this.position[i] = p[i];
        }
    }
    public boolean Goal(){
        int[] a = {0,0,0};
        return Arrays.equals(this.position,a);
    }
    public void ExpandMove(){
        MoveOneC();
        MoveOneM();
        MoveTwoC();
        MoveTwoM();
        MoveOneE();
    }
    public void MoveOneC(){
        int[] pc = this.position.clone();
        if(pc[2]==0){
            if(pc[1]<=2){
                pc[1]+=1;
                pc[2] = 1;
            }
        }
        else{
            if(pc[1]>=1){
                pc[1]-=1;
                pc[2] = 0;
            }
        }
        if(!Arrays.equals(pc,this.position)){
            if(!isNotValid(pc)){
                State child = new State(pc);
                children.add(child);
                child.parent = this;
            }
        }
    }
    public void MoveOneM(){
        int[] pc = this.position.clone();
        if(pc[2]==0){
            if(pc[0]<=2){
                pc[0]+=1;
                pc[2] = 1;
            }
        }
        else{
            if(pc[0]>=1){
                pc[0]-=1;
                pc[2] = 0;
            }
        }
        if(!Arrays.equals(pc,this.position)){
            if(!isNotValid(pc)){
                State child = new State(pc);
                children.add(child);
                child.parent = this;
            }
        }
    }
    public void MoveTwoC(){
        int[] pc = this.position.clone();
        if(pc[2]==0){
            if(pc[1]<=1){
                pc[1]+=2;
                pc[2] = 1;
            }
        }
        else{
            if(pc[1]>=2){
                pc[1]-=2;
                pc[2] = 0;
            }
        }
        if(!Arrays.equals(pc,this.position)){
            if(!isNotValid(pc)){
                State child = new State(pc);
                children.add(child);
                child.parent = this;
            }
        }
    }
    public void MoveTwoM(){
        int[] pc = this.position.clone();
        if(pc[2]==0){
            if(pc[0]<=1){
                pc[0]+=2;
                pc[2] = 1;
            }
        }
        else{
            if(pc[0]>=2){
                pc[0]-=2;
                pc[2] = 0;
            }
        }
        if(!Arrays.equals(pc,this.position)) {
            if (!isNotValid(pc)) {
                State child = new State(pc);
                children.add(child);
                child.parent = this;
            }
        }
    }
    public void MoveOneE(){
        int[] pc = this.position.clone();
        if(pc[2]==0){
            if(pc[0]<=2 && pc[1]<=2){
                pc[0]+=1;
                pc[1]+=1;
                pc[2] = 1;
            }
        }
        else{
            if(pc[0]>=1 && pc[1]>=1){
                pc[0]-=1;
                pc[1]-=1;
                pc[2] = 0;
            }
        }
        if(!Arrays.equals(pc,this.position)){
            if(!isNotValid(pc)){
                State child = new State(pc);
                children.add(child);
                child.parent = this;
            }
        }
    }
    public void PrintState(){
        int a = position[0];
        int b = position[1];
        for(int i = 0; i<position.length;i++){
            System.out.print(position[i]);
            System.out.print(" ");
        }
        System.out.print((3-a)+" ");
        System.out.print((3-b)+" ");
        System.out.println();
    }
    public boolean isNotValid(int[] pc){
        boolean invalid = false;
        if(pc[0]>3 || pc[1]>3 || pc[0]<0 || pc[1]<0){
            invalid = true;
        }
        if(pc[0] == 2 && pc[1] == 3){
            invalid = true;
        }
        if(pc[0] == 1 && pc[1] == 3){
            invalid = true;
        }
        if(pc[0] == 1 && pc[1] == 2){
            invalid = true;
        }
        if(pc[0] == 2 && pc[1] == 1){
            invalid = true;
        }
        if(pc[0] == 1 && pc[1] == 0){
            invalid = true;
        }
        if(pc[0] == 2 && pc[1] == 0){
            invalid = true;
        }
        return invalid;
    }
}
class Uninformed {
    public Uninformed() {
    }

    public ArrayList<State> BFS(State root){
        ArrayList<State> PathToSolution = new ArrayList<State>();
        ArrayList<State> OpenList = new ArrayList<State>();
        ArrayList<State> CloseList = new ArrayList<State>();
        OpenList.add(root);
        boolean goalFound = false;
        while(OpenList.size()>0 && !goalFound){
            State currNode = OpenList.get(0);
            CloseList.add(currNode);
            OpenList.remove(0);
            currNode.ExpandMove();
//            currNode.PrintPuzzle();
            for (int i =0;i<currNode.children.size();i++){
                State currChild = currNode.children.get(i);
                if(currChild.Goal()){
                    goalFound = true;
                    PathTrace(PathToSolution, currChild);
                }
                if(!Contains(OpenList,currChild) && !Contains(CloseList,currChild)){
                    OpenList.add(currChild);
                }
            }
        }
        return PathToSolution;
    }
    public void PathTrace(ArrayList<State> path, State n){
        State current = n;
        path.add(current);
        while(current.parent != null){
            current = current.parent;
            path.add(current);
        }
    }
    public static boolean Contains(ArrayList<State> list, State c){
        boolean contains = false;
        for (int i =0 ; i< list.size();i++){
            if(Arrays.equals(list.get(i).position,c.position)){
                contains = true;
            }
        }
        return  contains;
    }

}
