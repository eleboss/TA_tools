import java.util.*;

class Q1b {
    public static void main(String[] args) {
        System.out.println("Please enter the puzzle, each digit followed by a space:");
        int[] puzzle = new int[9];
        Scanner scanner = new Scanner(System.in);
        for (int i = 0; i<puzzle.length;i++){
            int j = scanner.nextInt();
            puzzle[i] = j;
        }
        Node initNode = new Node(puzzle);
        System.out.println("Entered puzzle is:");
        initNode.PrintPuzzle();
        System.out.println("Finding solution");
        Informed inf = new Informed();
        System.out.println("Running with Manhattan Distance as Heuristic");
        ArrayList<Node> solution = inf.Astar(initNode,true);
        if(solution == null){
            System.out.println("Checked over 1 million elements");
        }
        else if(solution.size()>0){
            Collections.reverse(solution);
            System.out.println("Goal Found and now tracing its path...");
            for(int i=0;i<solution.size();i++){
                solution.get(i).PrintPuzzle();
            }
            System.out.println("Depth = "+ (solution.size()-1));
        }
        else{
            System.out.println("No path found till 10000 depth");
        }
        System.out.println("Running with Misplaced Tiles as Heuristic");
        ArrayList<Node> solution2 = inf.Astar(initNode,false);
        if(solution2 == null){
            System.out.println("Checked over 1 million elements");
        }
        else if(solution2.size()>0){
            Collections.reverse(solution2);
            System.out.println("Goal Found and now tracing its path...");
            for(int i=0;i<solution2.size();i++){
                solution2.get(i).PrintPuzzle();
            }
            System.out.println("Depth = "+ (solution2.size()-1));
        }
        else{
            System.out.println("No path found till 10000 depth");
        }
    }
}
class CompareNodes implements Comparator<Node> {
    @Override
    public int compare(Node n1, Node n2) {
        if(n1.heuristic>n2.heuristic){
            return 1;
        }
        else if(n2.heuristic>n1.heuristic){
            return -1;
        }
        return 0;
    }
}
class Informed {
    public ArrayList<Node> Astar(Node root, boolean isMan){
        ArrayList<Node> PathToSolution = new ArrayList<Node>();
        Comparator<Node> comparator = new CompareNodes();
        PriorityQueue<Node> pQ = new PriorityQueue<Node>(100,comparator);
        ArrayList<Node> visited = new ArrayList<Node>();
        root.depth = 0;
        Node goalNode = null;
        pQ.add(root);
        visited.add(root);
        while(!pQ.isEmpty()){
            Node current = pQ.remove();
            current.ExpandMove();
            for (int i =0;i<current.children.size();i++){
                Node currChild =  current.children.get(i);
                if(currChild.Goal()){
                    currChild.depth = currChild.parent.depth+1;
                    goalNode = currChild;
                    break;
                }
                else{
                    boolean abc = false;
                    for (int j = 0;j<visited.size();j++){
                        abc = Arrays.equals(visited.get(j).puzzle,currChild.puzzle);
                        if(abc){
                            break;
                        }
                    }
                    if(!abc){
                        currChild.depth = currChild.parent.depth+1;
                        visited.add(currChild);
                        if(isMan){
                            currChild.heuristic = ManhattanDist(currChild);

                        }
                        else{
                            currChild.heuristic = MisplacedTiles(currChild);
                        }
                        pQ.add(currChild);
                    }
                }
            }
            if(goalNode!=null){
                break;
            }
        }

        PathTrace(PathToSolution,goalNode);
        return PathToSolution;
    }
    public int MisplacedTiles(Node root){
        int count = 0;
        for (int i=1; i<root.puzzle.length;i++){
            if(root.puzzle[i]!=i){
                count+=1;
            }
        }
        return count+root.depth;
    }
    public int ManhattanDist(Node root){
        int count = 0;
        for (int i = 0; i<9;i++){
            int j = root.puzzle[i];
            int ori_x = j/3;
            int ori_y = j%3;
            int dest_x = i/3;
            int dest_y = i%3;
            count+= Math.abs(ori_x-dest_x)+Math.abs(ori_y-dest_y);
        }
        return count + root.depth;
    }
    public void PathTrace(ArrayList<Node> path, Node n){
        Node current = n;
        path.add(current);
        while(current.parent != null){
            current = current.parent;
            path.add(current);
        }
    }
}
class Node {
    public ArrayList<Node> children = new ArrayList<>();
    public Node parent;
    public int[] puzzle = new int[9];
    public int x = 0;
    public int col = 3;
    public int depth;
    public int heuristic;
    public Node(int[] p){
        for( int i = 0; i<puzzle.length;i++){
            this.puzzle[i] = p[i];
        }
    }
    public boolean Goal(){
        boolean isGoal = true;
        for (int i = 0; i<puzzle.length;i++){
            if(i != puzzle[i])
            {
                isGoal = false;
                break;
            }
        }
        return isGoal;
    }
    public void ExpandMove(){
        for(int i = 0;i<puzzle.length;i++){
            if(puzzle[i]==0){
                x=i;
            }
        }
        MoveRight(puzzle,x);
        MoveLeft(puzzle,x);
        MoveDown(puzzle,x);
        MoveUp(puzzle,x);
    }
    public void MoveRight(int[] p, int i){
        if(i%col<col-1){
            int [] pc = p.clone();
            int temp = pc[i+1];
            pc [i+1] = pc[i];
            pc[i] = temp;
            Node child = new Node(pc);
            children.add(child);
            child.parent = this;
        }
    }
    public void MoveLeft(int[] p, int i){
        if(i%col>0){
            int [] pc = p.clone();
            int temp = pc[i-1];
            pc [i-1] = pc[i];
            pc[i] = temp;
            Node child = new Node(pc);
            children.add(child);
            child.parent = this;
        }

    }
    public void MoveUp(int[] p, int i){
        if(i-col>=0){
            int [] pc = p.clone();
            int temp = pc[i-3];
            pc [i-3] = pc[i];
            pc[i] = temp;
            Node child = new Node(pc);
            children.add(child);
            child.parent = this;
        }
    }
    public void MoveDown(int[] p, int i){
        if(i+col<puzzle.length){
            int [] pc = p.clone();
            int temp = pc[i+3];
            pc [i+3] = pc[i];
            pc[i] = temp;
            Node child = new Node(pc);
            children.add(child);
            child.parent = this;
        }
    }
    public void PrintPuzzle(){
        int m = 0;
        for (int i =0;i<col;i++){
            for(int j = 0; j<col;j++){
                System.out.print(puzzle[m]);
                m++;
            }
            System.out.println();
        }
        System.out.println();
    }
//    public boolean isSamePuzzle(int[] p){
//        boolean samePuz = true;
//        for(int i =0; i<p.length;i++){
//            if(puzzle[i]!=p[i]){
//                samePuz = false;
//            }
//        }
//        return samePuz;
//    }
}


