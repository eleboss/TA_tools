#include<iostream>
#include<vector>
using namespace std;

struct State{
	//store each position of the matrix as a number
	int input[3][3];
	//parent of the current state is the previous state
	int parent;
	//the current state value as a number
	int current;
	//the number of moves used until the current state
	int move;
	//store the value of zero
};

State temp;
int zero_x = 0;
int zero_y = 0;

int storeAsNum(int input[3][3]){
	//change the matrix to a number for easier storage and compare
	int firstDigit = 100000000;
	int number = 0;
	for(int i = 0; i < 3; i++){
		for(int j = 0; j < 3; j++){
			number += input[i][j] * firstDigit;
			firstDigit = firstDigit/10;
		}
	}
	return number;
};

//find the value of "o"
void find_zero(){
	for(int i = 0; i<3; i++){
		for(int j = 0; j<3; j++){
			if(temp.input[i][j] == 0){
				zero_x = i;
				zero_y = j;
				return;
			}
		}
	}
}

bool up(int input[3][3]){
	//move the "0" upwards
	if(zero_x == 0)
		return false;
	else{
		zero_x = zero_x - 1;
		input[zero_x][zero_y] = input[zero_x-1][zero_y];
		input[zero_x-1][zero_y] = 0;
		return true;
	}
};

bool down(int input[3][3]){
	//move the "0" downwards
	if(zero_x == 2)
		return false;
	else{
		zero_x = zero_x + 1;
		input[zero_x][zero_y] = input[zero_x+1][zero_y];
		input[zero_x+1][zero_y] = 0;
		return true;
	}
};

bool left(int input[3][3]){
	//move the "0" leftwards
	if(zero_y == 0)
		return false;
	else{
		zero_y = zero_y - 1;
		input[zero_x][zero_y] = input[zero_x][zero_y-1];
		input[zero_x][zero_y-1] = 0;
		return true;
	}
};

bool right(int input[3][3]){
	//move the "0" rightwards
	if(zero_y == 2)
		return false;
	else{
		zero_y = zero_y + 1;
		input[zero_x][zero_y] = input[zero_x][zero_y+1];
		input[zero_x][zero_y+1] = 0;
		return true;
	}
}

int main(){
	int input[3][3] = {0};
	//checked is the vector stores the matrix that has not been checked, notChecked stores the matrix that has been checked
	vector <State> checked;
	vector <State> notChecked;
	State start;
	int move = 0;

	cout<<"Please input the value of the initial state, from left to right, from up to down, with an empty space between each input and 0 representing the empty tile: "<< endl;
	for(int i = 0; i < 3; i++){
		for(int j = 0; j < 3; j++){
			cin >> input[i][j];
			start.input[i][j] = input[i][j];
		}
	}

	cout << "Calculating..." << endl;

	start.parent = 0;
	start.current = storeAsNum(input);
	start.move = 0;
	checked.push_back(start);

	//set the goal as a number for comparison
	int goal = 012345678;
	//turn to true if the goal is reached
	bool reachGoal = false;
	int count = 1;

	while(!checked.empty()){
		//use size - 1 to find the most recent matrix
		temp.current = checked[checked.size()-1].current;
		temp.parent = checked[checked.size()-1].parent;
		temp.move = checked[checked.size()-1].move;
		for(int i = 0; i < 2; i++){
			for(int j = 0; j < 2; j++){
				temp.input[i][j] = checked[checked.size()-1].input[i][j];
			}
		}

		//delete the temp from the vector checked
		checked.pop_back();
		//add the temp to the vector notChecked
		notChecked.push_back(temp);
		if(temp.current == goal){
			//stop if the goal is found
			reachGoal = true;
			break;
		}

		//there may be 4 different state produced when moving the 0 block
		State temprory[4];
		for (int i = 0; i < 4; i++){
			temprory[i].parent = temp.current;
			for(int m = 0; m < 3; m++){
				for(int n = 0; n < 3; n++){
					temprory[i].input[m][n] = temp.input[m][n];
					temprory[i].move = temp.move + 1;
				}
			}
		}

		bool checkTemp[4][2];
		//check if the new produced state by the movement is already in the checked(0) notChecked(1) vector
		for (int i = 0; i < 4; i++)
			for (int j = 0; j < 2; j++)
				checkTemp[i][j] = false;

		if(up(temprory[0].input)){
			temprory[0].current = storeAsNum(temprory[0].input);
			for(int i = 0; i< checked.size();i++){
				if(checked[i].current == temprory[0].current){
					//the newly produced state already in the checked vector
					checkTemp[0][0] = true;
					break;
				}
			}
			if(!checkTemp[0][0]){
				for (int i = 0; i < notChecked.size(); ++i)
				{
					if(notChecked[i].current == temprory[0].current){
						checkTemp[0][1] = true;
						break;
					}
				}
				if(!checkTemp[0][1])
					checked.push_back(temprory[0]);
			}
		}

		if(down(temprory[1].input)){
			temprory[1].current = storeAsNum(temprory[1].input);
			for(int i = 0; i< checked.size();i++){
				if(checked[i].current == temprory[1].current){
					//the newly produced state already in the checked vector
					checkTemp[1][0] = true;
					break;
				}
			}
			if(!checkTemp[1][0]){
				for (int i = 0; i < notChecked.size(); ++i)
				{
					if(notChecked[i].current == temprory[1].current){
						checkTemp[1][1] = true;
						break;
					}
				}
				if(!checkTemp[1][1])
					checked.push_back(temprory[1]);
			}
		}

		if(left(temprory[2].input)){
			temprory[2].current = storeAsNum(temprory[2].input);
			for(int i = 0; i< checked.size();i++){
				if(checked[i].current == temprory[2].current){
					//the newly produced state already in the checked vector
					checkTemp[2][0] = true;
					break;
				}
			}
			if(!checkTemp[2][0]){
				for (int i = 0; i < notChecked.size(); ++i)
				{
					if(notChecked[i].current == temprory[2].current){
						checkTemp[2][1] = true;
						break;
					}
				}
				if(!checkTemp[2][1])
					checked.push_back(temprory[2]);
			}
		}

		if(right(temprory[3].input)){
			temprory[3].current = storeAsNum(temprory[3].input);
			for(int i = 0; i< checked.size();i++){
				if(checked[i].current == temprory[3].current){
					//the newly produced state already in the checked vector
					checkTemp[3][0] = true;
					break;
				}
			}
			if(!checkTemp[3][0]){
				for (int i = 0; i < notChecked.size(); ++i)
				{
					if(notChecked[i].current == temprory[3].current){
						checkTemp[3][1] = true;
						break;
					}
				}
				if(!checkTemp[3][1])
					checked.push_back(temprory[3]);
			}
		}
	}

	if(reachGoal){
		vector<State> output;
		output.push_back(temp);
		int parent = temp.parent;

		while(parent != 0){
			for(int m = 0; m< notChecked.size(); m++){
				if(notChecked[m].current == parent){
					temp.current = notChecked[m].current;
					temp.move = notChecked[m].move;
					temp.parent = notChecked[m].parent;
					for(int n = 0; n < 3; n++){
						for(int p = 0; p < 3; p++){
							temp.input[n][p] = notChecked[m].input[n][p];
						}
					}
					output.push_back(temp);
					parent = notChecked[m].parent;
					break;
				}
			}
		}

		/*State answer;
		answer.current = 012345678;
		answer.move = temp.move+1;
		answer.parent = temp.current;
		for (int i = 0; i<2;i++){
			for(int j=0;j<2;j++){
				answer.input[i][j] = i+j;
			}
		}
		output.push_back(answer);*/

		for(int i = output.size()-1; i >=0; i--){
			cout << "the" << output.size()-i-1 << "path is:" << endl;
			for(int j = 0; j < 3; j++){
				for(int k = 0; k < 3; k++){
					cout << output[i].input[j][k] << "";
				}
				cout << endl;
			}
		}
	}

	else
		cout << "Cannot find the path!" << endl;
}
