import java.util.LinkedList;
import java.util.Queue;

public class questiontwo{
	//create a new state queue for searching
	private Queue<State> q = new LinkedList<State>();

	//define class State and its contents
	private class State{
		//define the number of missionaries and cannibals on the start side of the river which can be 0,1,2,3
		private int missionary;
		private int cannibal;
		//define the number of boat on the start side of the river which can be 0,1
		private int boat;
		//record the last state to perform the path easily
		private State laststate;
		//define an integer to record the height og the tree
		private int treeheight;

		//constructor
		public State(int missionary, int cannibal, int boat, int treeheight){
			this(missionary, cannibal, boat, null, treeheight);
		}

		//constructor
		public State(int missionary, int cannibal, int boat, State previousstate, int treeheight){
			this.missionary = missionary;
			this.cannibal = cannibal;
			this.boat = boat;
			this.laststate = previousstate;
			this.treeheight = treeheight;
		}

		//get the height og the tree
		public int gettreeheight(){
			return this.treeheight;
		}

		//check if the current state is a valid state
		public boolean isvalid(){
			if(missionary < 0 || missionary > 3 || cannibal < 0 || cannibal > 3)
				//missionary and cannibal number on the start side of the river can only be 0,1,2,3
				return false;
			if(missionary > 0 && cannibal > missionary)
				//the number of cannibal is greater than missionary for the start side of the river, which is invalid
				return false;
			if(3 - missionary > 0 && 3 - cannibal > 3 - missionary)
				//the number of cannibal is greater than missionary for the end side of the river, which is invalid
				return false;
			else
				return true;
		}

		//check if the current state is the goal state
		public boolean checkgoal(){
			//0,0,0 is the goal state
			State goal = new State(0,0,0,99999);
			return checkequal(goal);
		}

		//check if the two states are equal
		public boolean checkequal(State a){
			return (a.missionary == this.missionary && a.cannibal == this.cannibal && a.boat == this.boat);
		}

		//print the path
		public void print(){
			if(this.laststate != null){
				this.laststate.print();
			}
			String startside = this.boat == 1 ? "Boat from start to end" : "Boat from end to start";
			System.out.println(this.missionary + "M/" + this.cannibal + "C " + " " + (3-this.missionary) + "M/" + (3-this.cannibal) + "C");
			System.out.println(startside);
		}
	}

	//to generate the next movement of the boat, how many people of which kind it carrys
	private void nextstep(State currentState){
		for (int i = 0; i < 3; i++){
			for(int j = 0; j < 3; j++){
				if(i == 0 && j == 0)
					continue;
				if(i + j > 2)
					//a boat cannot take more than two people
					break;
				addStatetoQueue(currentState, i , j);
			}
		}
	}

	private void addStatetoQueue(State previousstate, int missionary, int cannibal){
		int startside = previousstate.boat == 1 ? -1 : 1;
		State state = new State(previousstate.missionary + startside * missionary, previousstate.cannibal + startside * cannibal, 1 - previousstate.boat, previousstate, previousstate.gettreeheight() + 1);
		if(state.isvalid())
			//add the state to the queue if the new state provided by the above step is valid
			q.add(state);
	}

	public void solve(){
		int height = 0;
		int count = 0;
		//set if the state first found to false to start program
		boolean issolutionfound = false;
		//set if the program is complete to false to start program
		boolean iscomplete = false;

		State start = new State(3,3,1,1);
		q.add(start);

		while(!q.isEmpty() && !iscomplete){
			State current = q.remove();
			if(current.checkgoal()){
				if(issolutionfound){
					if(current.gettreeheight() <= height){
						count++;
						System.out.println("No: " + count + " solution is ");
						current.print();
						System.out.println();
					}
					else{
						issolutionfound = true;
					}
				}else{
					//this is the first time the goal is found, in this part the output needs to write the height of the tree, next change the issolutionfound to true to process the above situation when issolutionfound is true
					issolutionfound = true;
					height= current.gettreeheight();
					count++;
					System.out.println("No: " + count + " solution, the search tree height is "+ height);
					current.print();
					System.out.println();
				}
			}else{
				nextstep(current);
			}
		}
	}

	public static void main(String[] args){
		questiontwo sol = new questiontwo();
		sol.solve();
	}

}