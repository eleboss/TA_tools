import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.time.Instant;
import java.time.Duration;

/*
  author @Maoqi Zhang
  this is the method of IDS
 */

public class Q1a {
    Instant start;
    long timeElapsed = 0;
    int expand = 0;
    State initial;
    static int[] goal = {0,1,2,3,4,5,6,7,8};
    HashSet<State> closed = new HashSet<>();
    static State terminal;
    public Q1a(String input) {
        String[] a = input.split(" ");
        int i = 0;
        int[] initialMatrix = new int[9];
        for (String j: a) {
            initialMatrix [i] = Integer.parseInt(j); i++;
        }
        initial = new State(initialMatrix,null);
    }

    public static boolean ValidInput(String input) {
        String p = "[0-8]\\s[0-8]\\s[0-8]\\s[0-8]\\s" +
                "[0-8]\\s[0-8]\\s[0-8]\\s[0-8]\\s[0-8]";
        Pattern InputPattern = Pattern.compile(p);
        Matcher PMatcher = InputPattern.matcher(input);
        if (!PMatcher.matches()) {
            return false;
        } else {
            List<String> all = Arrays.asList(input.split(" "));
            for (int i = 0; i < 9 ; i++) {
                if (!all.contains(String.valueOf(i))) {return false;};
            }
            return true;
        }
    }

    // represent the state by a 3-by-3 matrix
    public static class State {
        State parent;
        int[] curr;
        int depth;
        ArrayList<State> children = new ArrayList<>();

        public State(int[] curr, State parent) {
            this.parent = parent;
            if (parent == null) {depth = 1;} else {depth = parent.depth + 1;}
            this.curr = curr;
        }

        public boolean isGoal() {
            for (int i = 0; i < 9; i++) {
                if (curr[i] != goal[i]) {return false;}
            }
            terminal = this;
            return true;
        }


        @Override
        public boolean equals(Object o) {
            for (int i = 0; i < 9; i++) {
                if (this.curr[i] != ((State) o).curr[i]) {return false;}
            }
            return true;
        }

        @Override
        public String toString() {
            String result = "";
            for (int i = 0; i < 9; i++) {
                result = result + this.curr[i];
                if (i%3 == 2) {
                    result = result + "\n";
                }
            }
            return result;
        }

        @Override
        public int hashCode() {
            int hash = 0;
            for (int i = 1; i < 9; i++) {
                hash =  hash*10 + this.curr[i];
            }
            return hash;
        }
    }

    public void IDS() {
        start = Instant.now();
        int i = 1;
        while (expand < 1000000) {
            if (IDSHelper(i) == true) {
                i = i-1;
                Instant finish = Instant.now();
                timeElapsed = Duration.between(start, finish).toMillis();
                System.out.println("Moves:" + i);
                System.out.println("Expanded Nodes: " + expand);
                System.out.println("Search time (/milliseconds): "+ timeElapsed);
                this.printPath();
                return;
            }
            i = i + 1;
        }
        System.out.println("cannot find solution within 100,000 nodes expanded");
    }

    public void printPath() {
        State temp = terminal;
        ArrayList<State> path = new ArrayList<>();
        while ((temp.depth > 1)) {
            path.add(temp);
            temp = temp.parent;
        }
        path.add(temp);
        Collections.reverse(path);
        for (State a: path) {
            System.out.println(a);
        }
    }

    public void getChildren(State a) {
        // move according to the placement of (empty tile)
        for (int i = 0; i < 9; i++) {
            if (a.curr[i] == 0) {
                if (i>2) {
                    swap(a,i,i-3);
                }
                if (i<6) {
                    swap(a,i,i+3);
                }
                if (i%3 > 0) {
                    swap(a,i,i-1);
                }
                if (i%3 < 2) {
                    swap(a,i,i+1);
                }
                this.expand = this.expand + 1;
                break;
            }
        }
    }

    //helper function for getting children
    public void swap(State curr,int i,int j) {
        int[] temp = new int[9];
        System.arraycopy(curr.curr,0,temp,0,9);
        int a = temp[i];
        temp[i] = temp[j];
        temp[j] = a;
        State b = new State(temp,curr);
        if (!closed.contains(b)) {
            curr.children.add(b);
        }
    }

    //helper function for IDS
    public boolean IDSHelper(int i) {
        Stack<State> fringe = new Stack<State>();
        fringe.add(initial);
        while (!fringe.isEmpty()) {
            State temp = fringe.pop();
            this.closed.add(temp);
            if (temp.isGoal()) {
                return true;
            } else if (temp.depth < i) {
                if (temp.children.size() == 0) {
                    this.getChildren(temp);
                }
                for (State a : temp.children) {
                    fringe.add(a);
                }
            }
        }
        return false;
    }

    public static void main (String[]args){
        Scanner myObj = new Scanner(System.in);  // Create a Scanner object
        System.out.println("Enter initial state: \n(number from 0-8, each one " +
                  "only once, separated by space in between)");
        while (true) {
            String input = myObj.nextLine();
            if (Q1a.ValidInput(input) == true) {
                Q1a a = new Q1a(input);
                a.IDS();
                break;
            }
            System.out.println("Incorrect input, please try again");
        }
    }
}
