import java.util.ArrayList;
import java.util.LinkedList;
import java.util.HashSet;
import java.util.Stack;
/*
  author @Maoqi Zhang
  use iterative deepening method to search for
  result for missionary and cannibals problems
 */

 //Operation time on my own comp(using stopwatch) :

public class Q2 {
    State initialState;
    int step;
    State terminal;

    public Q2(State i, int step) {
        initialState = i;
        this.step = step;
    }

    public boolean search() {
        for (int i = 1; i <= step ; i++) {
            if (DFS(i) == true) {
                return true;
            }
        }
        return false;
    }

    public boolean DFS(int i){
        Stack<State> fringe = new Stack<State>();
        HashSet<State> visited = new HashSet<State>();
        fringe.push(initialState);
        while ( !fringe.isEmpty()) {
            State temp = fringe.pop();
            visited.add(temp);
            if (temp.GoalState()) {
                terminal = temp;
                return true;
            } else if (temp.depth < i) {
                if (temp.children.size() == 0) {temp.getChildren();}
                for (State a: temp.children) {
                    if (!visited.contains(a)) {fringe.push(a);}
                }
            }
        }
        return false;
    }

    public LinkedList<State> Path() {
        State temp = terminal;
        LinkedList<State> result = new LinkedList<State>();
        result.add(temp);
        while (temp.Parent != null) {
            temp = temp.Parent;
            result.addFirst(temp);
        }
        return result;
    }

    public void printPath() {
        if (search() != true) {
            System.out.print("No solution exist.") ;
        } else {
            LinkedList<State> path = Path();
            for (State a: path) {
                System.out.println(a);
            }
        }
    }

    public static class State {
        State Parent;
        int CLeft;
        int MLeft;
        int boatSide;
        int depth;
        ArrayList<State> children = new ArrayList<State>();

        public State(int C,int M,int boatside) {
            depth = 1;
            CLeft = C;
            MLeft = M;
            boatSide = boatside;
        }

        public State(State parent, int C, int M, int boatside) {
            depth = parent.depth + 1;
            Parent = parent;
            CLeft = C;
            MLeft = M;
            boatSide = boatside;
        }

        public boolean validState() {
            if (this.MLeft == 3 || this.MLeft == 0) {
                return true;
            } else {return this.CLeft == this.MLeft;}
        }

        public boolean GoalState() {
            return CLeft == 0 && MLeft == 0 && boatSide == 1;
        }

        public void getChildren() {
            if (boatSide == 0) {
                for (int i = 0; i <= Math.min(2,CLeft);i++) {
                    for (int j = 0; j <= Math.min(2,MLeft); j++) {
                        if (i+j != 0 && i+j <= 2) {
                            State a = new State(this,CLeft-i,MLeft-j,1);
                            if (a.validState()) {children.add(a);}
                        }
                    }
                }
            } else {
                for (int i = 0; i <= Math.min(2,3-CLeft);i++) {
                    for (int j = 0; j <= Math.min(2,3-MLeft); j++) {
                        if (i+j != 0 && i+j <= 2) {
                            State a = new State(this,CLeft + i,MLeft + j,0);
                            if (a.validState()) {children.add(a);}
                        }
                    }
                }
            }
        }

        @Override
        public boolean equals(Object o) {
            if (!(o instanceof State)) {
                return false;
            } else {
                return ((State) o).CLeft == this.CLeft && ((State) o).MLeft == MLeft
                        && ((State) o).boatSide == this.boatSide;
            }
        }

        @Override
        public String toString() {
            return "("+CLeft+","+MLeft+","+boatSide + ")";
        }

        @Override
        public int hashCode() {
            int hash = 0;
            hash = 10 * hash + this.MLeft;
            hash = 10 * hash + this.CLeft;
            hash = 10 * hash + this.boatSide;
            return hash;
        }

    }

    public static void main(String[] args) {
        State initial = new State(3, 3, 0);
        Q2 search = new Q2(initial, 30);
        search.printPath();
    }
}
