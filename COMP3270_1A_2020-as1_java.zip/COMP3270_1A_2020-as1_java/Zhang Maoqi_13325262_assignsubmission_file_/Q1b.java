import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.time.Instant;
import java.time.Duration;

/*
  author @Maoqi Zhang
  this is the method of IDS
 */

public class Q1b {
    Instant start;
    long timeElapsed = 0;
    int expand = 0;
    static State initial;
    static State terminal;
    HashSet<State> closed = new HashSet<State>();
    static int heuristicType;
    public Q1b(String input,int h) {
        String[] a = input.split(" ");
        int i = 0;
        heuristicType = h;
        int[] initialMatrix = new int[9];
        for (String j: a) {
            initialMatrix [i] = Integer.parseInt(j); i++;
        }
        initial = new State(initialMatrix,null);
    }

    public static boolean ValidInput(String input) {
        String p = "[0-8]\\s[0-8]\\s[0-8]\\s[0-8]\\s" +
                "[0-8]\\s[0-8]\\s[0-8]\\s[0-8]\\s[0-8]";
        Pattern InputPattern = Pattern.compile(p);
        Matcher PMatcher = InputPattern.matcher(input);
        if (!PMatcher.matches()) {
            return false;
        } else {
            List<String> all = Arrays.asList(input.split(" "));
            for (int i = 0; i < 9 ; i++) {
                if (!all.contains(String.valueOf(i))) {return false;};
            }
            return true;
        }
    }

    // represent the state by a 3-by-3 matrix
    public static class State implements Comparable {
        State parent;
        int[] curr;
        int depth;
        static int[] goal = {0,1,2,3,4,5,6,7,8};
        int heuristic = 0;
        ArrayList<State> children = new ArrayList<State>();

        public State(int[] curr, State parent) {
            this.parent = parent;
            if (parent == null) {depth = 1;} else {depth = parent.depth + 1;}
            this.curr = curr;
                for (int i = 0; i < 9; i++) {
                    if (curr[i] != goal[i]) {
                        if (Q1b.heuristicType == 1) {
                            heuristic = heuristic + 1;
                        } else {
                            heuristic = heuristic +Math.abs(i/3-curr[i]/3)+Math.abs(i%3-curr[i]%3);
                        }
                    }
                }
                heuristic = heuristic + depth;
        }

        public boolean isGoal() {
            for (int i = 0; i < 9; i++) {
                if (curr[i] != goal[i]) {return false;}
            }
            terminal = this;
            return true;
        }

        @Override
        public int compareTo(Object o) {
            return this.heuristic - ((State) o).heuristic ;
        }

        @Override
        public boolean equals(Object o) {
            for (int i = 0; i < 9; i++) {
                if (this.curr[i] != ((State) o).curr[i]) {return false;}
            }
            return true;
        }

        @Override
        public String toString() {
            String result = "";
            for (int i = 0; i < 9; i++) {
                result = result + this.curr[i];
                if (i%3 == 2) {
                    result = result + "\n";
                }
            }
            return result;
        }

        @Override
        public int hashCode() {
            int hash = 0;
            for (int i = 1; i < 9; i++) {
                hash =  hash*10 + this.curr[i];
            }
            return hash;
        }
    }

    public void getChildren(State a) {
        // move according to the placement of (empty tile)
        for (int i = 0; i < 9; i++) {
            if (a.curr[i] == 0) {
                if (i>2) {
                    swap(a,i,i-3);
                }
                if (i<6) {
                    swap(a,i,i+3);
                }
                if (i%3 > 0) {
                    swap(a,i,i-1);
                }
                if (i%3 < 2) {
                    swap(a,i,i+1);
                }
                this.expand = this.expand + 1;
                break;
            }
        }
    }

    public void swap(State curr, int i, int j) {
        int[] temp = new int[9];
        System.arraycopy(curr.curr,0,temp,0,9);
        int a = temp[i];
        temp[i] = temp[j];
        temp[j] = a;
        State b = new State(temp,curr);
        if (!closed.contains(b)) {
            curr.children.add(b);
        }
    }

    public void printPath() {
        State temp = terminal;
        ArrayList<State> path = new ArrayList<>();
        while ((temp.depth > 1)) {
            path.add(temp);
            temp = temp.parent;
        }
        path.add(temp);
        Collections.reverse(path);
        int moves = path.size() -1;
        System.out.println("Moves: "+moves);
        System.out.println("Nodes expanded: "+expand);
        System.out.println("Search time (/milliseconds): "+ timeElapsed);
        for (State a: path) {
            System.out.println(a);
        }
    }

    //helper function for IDS
    public boolean Search() {
        this.start =  Instant.now();
        PriorityQueue<State> fringe = new PriorityQueue<State>();
        fringe.add(initial);
        while ( !fringe.isEmpty() && timeElapsed < 10000) {
            State temp = fringe.remove();
            closed.add(temp);
            if (temp.isGoal()) {
                return true;
            } else {
                getChildren(temp);
                for (State a: temp.children) {
                    if (!closed.contains(a)){
                        fringe.add(a);
                    }
                }
            }
            Instant finish = Instant.now();
            timeElapsed = Duration.between(start, finish).toMillis();
        }
        return false;
    }

    public static void main(String[] args) {
        Scanner myObj = new Scanner(System.in);  // Create a Scanner object
        System.out.println("Enter initial state: \n(number from 0-8, each one " +
                "only once, separated by space in between)");
        while (true) {
            String input = myObj.nextLine();
            if (Q1b.ValidInput(input) == true) {
                System.out.println("enter heuristic that will be used: \n" +
                        "1: Number of Misplaced Tiles \n" +
                        "2: Manhattan distance");
                while (true) {
                    String input2 = myObj.nextLine();
                    if (input2.equals("1")) {
                        Q1b a = new Q1b(input,1);
                        a.Search();
                        a.printPath(); break;
                    } else if (input2.equals("2")) {
                        Q1b a = new Q1b(input,2);
                        a.Search();
                        a.printPath(); break;
                    } else {
                        System.out.println("Invalid input, please try again");
                    }
                }
                break;
            }
            System.out.println("Invalid input, please try again");
        }
    }
}
