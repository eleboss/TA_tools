package Q1Submission;

import java.util.Scanner;
import java.util.Stack;



public class Q1a {
	static class state implements Comparable<state>{
		final int n = 3;
		final int[][] goal = {{0,1,2},{3,4,5},{6,7,8}};
		int[][] p;
		int cost;
		int h_cost;
		int man_cost;
		int t_cost;
		state parent;
		
		state(int[][] inputs){
			this.p = inputs;
			this.cost = 0;
			this.parent = null;
			this.h_cost = h_1();
			this.man_cost = manhattan();
			this.t_cost = this.h_cost + this.cost;
		}
		//copy constructor, meant to avoid leaky abstraction when accessing the 'p' array.
		public state(state s) {
			int[][] tmp = new int[3][3];
			for (int i = 0; i < 3; i++) {
				for (int j = 0; j < 3; j++) {
					tmp[i][j] = s.p[i][j];
				}
			}
			p = tmp;
			cost = s.cost;
			h_cost = s.h_cost;
			man_cost = s.man_cost;
			t_cost = s.t_cost;
			parent = s.parent;
			
		}
		//check if solution reached.
		public boolean isFinished() {
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n; j++) {
					if (p[i][j] != goal[i][j]) {
						return false;
					}
				}
			}
			return true;
		}
		//printer
		public void print() {
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n; j++) {
					System.out.print(p[i][j] + " ");
				}
				System.out.println();
			}
		}
		//misplaced tiles heuristic.
		public int h_1() {
			int count = 0;
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n; j++) {
					if (p[i][j] != goal[i][j]) {
						count++;
					}
				}
			}
			return count;
		}
		//manhattan distance calculator.
		public int manhattan() {
			int counter = 0;
			boolean tmp;
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n; j++) {
					tmp = false;
					for (int k = 0; k < n; k++) {
						for (int l = 0; l < n; l++) {
							if (p[k][l] == goal[i][j]) {
								counter += (Math.abs(i-k) + Math.abs(j - l));
								tmp = true;
							}
							if (tmp) {
								break;
							}
						}
						if (tmp) {
							break;
						}
					}
				}
			}
			return counter;
		}
		
		public int compareTo(state another) {
			if (t_cost == another.t_cost) {
				return 0;
			}
			else if (t_cost < another.t_cost) {
				return -1;
			}
			else {
				return 1;
			}
		}
		public boolean equals(Object obj) {
			if (!(obj instanceof state)) {
				return false;
			}
			state s = (state) obj;
			return (s.p[0][0] == p[0][0] && s.p[0][1] == p[0][1] && s.p[0][2] == p[0][2] &&
					s.p[1][0] == p[1][0] && s.p[1][1] == p[1][1] && s.p[1][2] == p[1][2] &&
					s.p[2][0] == p[2][0] && s.p[2][1] == p[2][1] && s.p[2][2] == p[2][2]);
		}
	}
	static class ids {
		state current;
		final int LIMIT = 1000000;
		static int breaker = 0; //increments for every node expanded, if > 1 million, end program.
		Stack<state> fringe = new Stack<state>();
		//Deque<state> tested = new LinkedList<>(); //tested states are stored here.
		public void expand() {
			//tested.addLast(current); //put parent state at last.
			for (int i = 0; i < 3; i++) {
				for (int j = 0; j < 3; j++) {
					if (current.p[i][j] == 0) { //find empty square
						if (i > 0) { //empty not at first row, shift it up.
							state temp = new state(current);
							temp.parent = current;
							swap(temp, i, j, i-1, j);
							//if (!tested.contains(temp)) { 
								temp.cost++;
								fringe.push(temp);
								//breaker++;
								//System.out.println("breaker = " + breaker);
							//}
						}
						
						if (i < 2) { //empty square not at last row, shift it down.
							state temp = new state(current);
							temp.parent = current;
							swap(temp, i, j, i+1, j);
							//if (!tested.contains(temp)) { // if temp not in tested, add it to fringe.
								temp.cost++;
								fringe.push(temp);
								//breaker++;
								//System.out.println("breaker = " + breaker);
							//}
						}
						if (j > 0) { //empty not at first column, shift it left.
							state temp = new state(current);
							temp.parent = current;
							swap(temp, i, j, i, j-1);
							//if (!tested.contains(temp)) {
								temp.cost++;
								fringe.push(temp);
								//breaker++;
								//System.out.println("breaker = " + breaker);

							//}
						}
						
						if (j < 2) { //empty not at last column, shift it right.
							state temp = new state(current);
							temp.parent = current;
							swap(temp, i, j, i, j+1);
							//if (!tested.contains(temp)) {
								temp.cost++;
								fringe.push(temp);
								//breaker++;
								//System.out.println("breaker = " + breaker);

							//}
						}
					}
				}
			}
			//fringe.remove(current);
		}
		
		public String IDS(state start) {
			long startTime = System.currentTimeMillis();
			int d = 0; //depth initialize.
			while (true) {
				current = new state(start);
				fringe.push(current);
				while (!fringe.isEmpty()) {
					if (breaker > LIMIT) {
						System.out.println("Over 1 million nodes expanded.");
						long endTime = System.currentTimeMillis();
						long duration = endTime - startTime;
						System.out.println("Time elapsed (in ms): "+ duration + "\n");
						return "Solution not found";
					}
					//current = fringe.peek();
					current = fringe.pop();
					breaker++;
					//System.out.println("Node counter = " + breaker);
					if (current.isFinished()) {
						long endTime = System.currentTimeMillis();
						long duration = endTime - startTime;
						System.out.println("Cost = " + current.cost + "\n");
						System.out.println("Nodes expanded = " + breaker + "\n");
						System.out.println("Time elapsed (in ms): "+ duration + "\n");
						path(current);
						return "\nSolution found.";
					}
					else if (d > current.cost) {
						expand();
					}
					//else {
						//fringe.pop();
					//}
				}
				fringe.clear();
				//tested.clear();
				d++;
			}
		}
		
		public void swap(state s, int a, int b, int c, int d) { //arr[a][b], arr[c][d] swapped.
			int temp = s.p[a][b];
			s.p[a][b] = s.p[c][d];
			s.p[c][d] = temp;
		}
		
		public void path(state s) {
			state tmp = s;
			while (tmp != null) {
				tmp.print();
				System.out.println();
				tmp = tmp.parent;
			}
		}
		
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int[][] inputs = new int[3][3];
		System.out.println("Enter your inputs:");
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				int a = sc.nextInt();
				inputs[i][j] = a;
			}
		}
		sc.close();
		state st = new state(inputs);
		ids test = new ids();
		System.out.println(test.IDS(st));
	}
}
