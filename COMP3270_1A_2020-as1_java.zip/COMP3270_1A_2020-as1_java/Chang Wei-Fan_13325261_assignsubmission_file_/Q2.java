package Q2Submission;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Set;


public class Q2 {
	static class State {

		int mRight; //Missionaries right.
		int cRight; //Cannibals right.
		int mLeft;
		int cLeft;
		int boatPos; //0 = boat on left. 1 = boat on right.
		int cost;
		State parent;
		
		//Constructor.
		public State(int mRight, int cRight, int mLeft, int cLeft, int boatPos, State parent, int cost) {
			this.mRight = mRight;
			this.cRight = cRight;
			this.mLeft = mLeft;
			this.cLeft = cLeft;
			this.boatPos = boatPos;
			this.parent = parent;
			this.cost = cost;
		}
		
		//Check if state is goal state.
		public boolean isFinished() {
			return (mLeft == 0 && cLeft == 0);
		}
		
		//Check if move is valid.
		public boolean isValid() { //check if c,m on left or right are larger or equal to 0 to avoid going lower than 0.
			if (mLeft >= 0 && cLeft >= 0 && mRight >= 0 && cRight >= 0 && (mRight == 0 || mRight >= cRight)
					&& (mLeft == 0 || mLeft >= cLeft)) {
				return true;
			}
			return false;
		}

		//Print function.
		public void print() {
			if (boatPos == 0) {
				System.out.println("Cannibal_left = " + cLeft + ", Missonary_left = " + mLeft + ", Boat on Left, " + "Cannibal_right = " + cRight 
						+ ", Missonary_right = " + mRight);
			}
			else {
				System.out.println("Cannibal_left = " + cLeft + ", Missonary_left = " + mLeft + ", Boat on Right, " + "Cannibal_right = " + cRight 
						+ ", Missonary_right = " + mRight);
			}
			System.out.println();
		}
		//Override equals for contains() function.
		public boolean equals(Object obj) {
			if (!(obj instanceof State)) {
				return false;
			}
			State s = (State) obj;
			return (s.mLeft == mLeft && s.cLeft == cLeft && s.mRight == mRight && s.cRight == cRight && s.boatPos == boatPos);
			
		}
	}
	static class BFS {
		static int node_counter = 0;
		//Breadth-First Search to find solution.
		public void solve(State start) {
				long startTime = System.currentTimeMillis();
				if (start.isFinished()) {
					long endTime = System.currentTimeMillis();
					long duration = endTime - startTime;
					System.out.println("Solution Found\n");
					System.out.println("Cost = " + start.cost + "\n");
					System.out.println("Total nodes expanded = " + node_counter + "\n");
					System.out.println("Time elapsed (in ms) = " + duration + "\n");
					path(start);
					return;
				}
				Queue<State> fringe = new LinkedList<State>();
				Set<State> tested = new HashSet<State>();
				fringe.add(start);
				while (true) {
					if (fringe.isEmpty()) {
						long endTime = System.currentTimeMillis();
						long duration = endTime - startTime;
						path(null);
						System.out.println("Total nodes expanded = " + node_counter + "\n");
						System.out.println("Time elapsed (in ms) = " + duration + "\n");
						return;
					}
					State s = fringe.poll();
					node_counter++;
					tested.add(s);
					ArrayList<State> arr = generateNodeArray(s);
					for (State tmp : arr) {
						if (!fringe.contains(tmp) || !tested.contains(tmp)) {
							if (tmp.isFinished()) {
								long endTime = System.currentTimeMillis();
								long duration = endTime - startTime;
								System.out.println("Solution Found.\n");
								System.out.println("Cost = " + tmp.cost + "\n");
								System.out.println("Total nodes expanded = " + node_counter + "\n");
								System.out.println("Time elapsed (in ms) = " + duration + "\n");
								path(tmp);
								return;
							}
							fringe.add(tmp);
						}
					}
			}
		}
		public ArrayList<State> generateNodeArray(State s){
			ArrayList<State> arr = new ArrayList<State>();
			if (s.boatPos == 0) {
				adder(arr, new State(s.mRight+1, s.cRight+1, s.mLeft-1, s.cLeft-1, 1, s, s.cost+1)); //move 1m and 1c to right
				adder(arr, new State(s.mRight+2, s.cRight, s.mLeft-2, s.cLeft, 1, s, s.cost+1)); //move 2m to right
				adder(arr, new State(s.mRight, s.cRight+2, s.mLeft, s.cLeft-2, 1, s, s.cost+1)); //move 2c to right
				adder(arr, new State(s.mRight+1, s.cRight, s.mLeft-1, s.cLeft, 1, s, s.cost+1)); //move 1m to right
				adder(arr, new State(s.mRight, s.cRight+1, s.mLeft, s.cLeft-1, 1, s, s.cost+1));
			}
			else {
				adder(arr, new State(s.mRight-1, s.cRight-1, s.mLeft+1, s.cLeft+1, 0, s, s.cost+1));
				adder(arr, new State(s.mRight-2, s.cRight, s.mLeft+2, s.cLeft, 0, s, s.cost+1));
				adder(arr, new State(s.mRight, s.cRight-2, s.mLeft, s.cLeft+2, 0, s, s.cost+1));
				adder(arr, new State(s.mRight-1, s.cRight, s.mLeft+1, s.cLeft, 0, s, s.cost+1));
				adder(arr, new State(s.mRight, s.cRight-1, s.mLeft, s.cLeft+1, 0, s, s.cost+1));
			}
			return arr;
		}
		public void adder(ArrayList<State> arr, State s) {
			if (s.isValid()) {
				arr.add(s);
			}
		}
		public void path(State s) {
			if (s == null) {
				System.out.println("No Solution Found.");
			}
			State tmp = s;
			while (tmp != null) {
				tmp.print();
				tmp = tmp.parent;
			}
			return;
		}
	}
	public static void main(String[] args) {
		State start = new State(0,0,3,3,0,null, 0);
		BFS test = new BFS();
		test.solve(start);
	}
}
