
//UID: 3035392775, Igor Afanasyev
import java.util.*;

public class CannibalMissionary {
    public static void main(String[] args) {
        List<Person> start = new ArrayList<>(List.of(Person.CANNIBAL, Person.CANNIBAL, Person.CANNIBAL,
                Person.MISSIONARY, Person.MISSIONARY, Person.MISSIONARY));


        List<Person> destination = new ArrayList<>();
        State state = new State(start, destination, true);

        Map<State, State> from = null;

        int i = 1;
        while (from == null) {
            from = state.solve(i);
            i++;
        }
        System.out.println((i - 1) + " moves made");

        State goal = new State(new ArrayList<>(), List.of(Person.CANNIBAL, Person.CANNIBAL, Person.CANNIBAL,
                Person.MISSIONARY, Person.MISSIONARY, Person.MISSIONARY), false);

        State current =  from.get(goal);
        List<State> order = new ArrayList<>();
        order.add(goal);

        while (current != null) {
            order.add(0, current);
            current = from.get(current);
        }

        for (State st : order) {
            System.out.println(st);
        }
    }

}

class State {

    List<Person> start;
    List<Person> destination;
    boolean boatAtStart;
    int nodeDepth = 0;

    public State(List<Person> start, List<Person> destination, boolean boatAtStart) {
        this.start = start;
        this.destination = destination;
        this.boatAtStart = boatAtStart;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        int maxLength = Math.max(start.size(), destination.size());
        for (int i = 0; i < maxLength; i++) {
            String leftSide = "";
            String rightSide = "";
            if (i < start.size()) {
                leftSide = start.get(i).toString();
            }
            if (i < destination.size()) {
                rightSide = destination.get(i).toString();
            }

            builder.append(String.format("%-" + Person.MISSIONARY.toString().length() + "s", leftSide));
            builder.append(" | ");
            builder.append(rightSide);
            builder.append(System.lineSeparator());
        }

        return builder.toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        State state = (State) o;
        return boatAtStart == state.boatAtStart &&
                Objects.equals(start, state.start) &&
                Objects.equals(destination, state.destination);
    }

    @Override
    public int hashCode() {
        return Objects.hash(start, destination, boatAtStart);
    }

    public Map<State, State> solve(int limit) {
        Set<State> visited = new HashSet<>();
        Deque<State> stack = new ArrayDeque<>();
        Map<State, State> from = new HashMap<>();
        boolean solutionFound = false;

        stack.push(this);
        while(!stack.isEmpty()) {
            State current = stack.pop();


            visited.add(current);
            if (current.isSolution()) {
                solutionFound = true;
                break;
            }

            //Subtree limit reached, continue to next element in stack
            if (current.nodeDepth == limit) {
                continue;
            }

            for (State successor : current.getSuccessors()) {
                if (!visited.contains(successor)) {
                    successor.nodeDepth = current.nodeDepth + 1;
                    from.put(successor, current);
                    stack.push(successor);
                }
            }


        }
        if (solutionFound) return from;
        return null;

    }

    public boolean isSolution() {
        return start.isEmpty();
    }


    public List<State> getSuccessors() {
        List<State> successors = new ArrayList<>();

        List<Person> from = null;
        List<Person> to = null;
        if (boatAtStart) {
            from = start;
            to = destination;
            //boat is at the right shore
        } else {
            from = destination;
            to = start;
        }

        if (from.contains(Person.MISSIONARY)) {
            List<Person> fromCopy = new ArrayList<>(from);
            fromCopy.remove(Person.MISSIONARY);
            List<Person> toCopy = new ArrayList<>(to);
            toCopy.add(Person.MISSIONARY);

            fromCopy.sort(Comparator.naturalOrder());
            toCopy.sort(Comparator.naturalOrder());

            //missionaries cannot be outnumbered by cannibals (or there are 0 missionaries)
            if (checkConditions(fromCopy, toCopy)) {
                //boat location is opposite at every more
                successors.add(this.makeSuccessor(fromCopy, toCopy, !boatAtStart));
            }

        }

        if (from.indexOf(Person.MISSIONARY) != from.lastIndexOf(Person.MISSIONARY)) {
            List<Person> fromCopy = new ArrayList<>(from);
            fromCopy.remove(Person.MISSIONARY);
            fromCopy.remove(Person.MISSIONARY);
            List<Person> toCopy = new ArrayList<>(to);
            toCopy.add(Person.MISSIONARY);
            toCopy.add(Person.MISSIONARY);
            fromCopy.sort(Comparator.naturalOrder());
            toCopy.sort(Comparator.naturalOrder());

            //missionaries cannot be outnumbered by cannibals (or there are 0 missionaries)
            if (checkConditions(fromCopy, toCopy)) {
                successors.add(this.makeSuccessor(fromCopy, toCopy, !boatAtStart));
            }
        }

        if (from.contains(Person.CANNIBAL)) {
            List<Person> fromCopy = new ArrayList<>(from);
            fromCopy.remove(Person.CANNIBAL);
            List<Person> toCopy = new ArrayList<>(to);
            toCopy.add(Person.CANNIBAL);
            fromCopy.sort(Comparator.naturalOrder());
            toCopy.sort(Comparator.naturalOrder());


            //missionaries cannot be outnumbered by cannibals (or there are 0 missionaries)
            if (checkConditions(fromCopy, toCopy)) {
                successors.add(this.makeSuccessor(fromCopy, toCopy, !boatAtStart));
            }
        }

        if (from.indexOf(Person.CANNIBAL) != from.lastIndexOf(Person.CANNIBAL)) {
            List<Person> fromCopy = new ArrayList<>(from);
            fromCopy.remove(Person.CANNIBAL);
            fromCopy.remove(Person.CANNIBAL);
            List<Person> toCopy = new ArrayList<>(to);
            toCopy.add(Person.CANNIBAL);
            toCopy.add(Person.CANNIBAL);

            fromCopy.sort(Comparator.naturalOrder());
            toCopy.sort(Comparator.naturalOrder());

            //missionaries cannot be outnumbered by cannibals (or there are 0 missionaries)
            if (checkConditions(fromCopy, toCopy)) {
                successors.add(this.makeSuccessor(fromCopy, toCopy, !boatAtStart));
            }
        }

        if (from.containsAll(List.of(Person.MISSIONARY, Person.CANNIBAL))) {
            List<Person> fromCopy = new ArrayList<>(from);
            fromCopy.remove(Person.CANNIBAL);
            fromCopy.remove(Person.MISSIONARY);
            List<Person> toCopy = new ArrayList<>(to);
            toCopy.add(Person.CANNIBAL);
            toCopy.add(Person.MISSIONARY);

            fromCopy.sort(Comparator.naturalOrder());
            toCopy.sort(Comparator.naturalOrder());

            //missionaries cannot be outnumbered by cannibals (or there are 0 missionaries)
            if (checkConditions(fromCopy, toCopy)) {
                successors.add(this.makeSuccessor(fromCopy, toCopy, !boatAtStart));
            }
        }

        return successors;
    }

    private boolean checkConditions(List<Person> fromCopy, List<Person> toCopy) {
        long missionInFrom = fromCopy.stream().filter((x) -> x == Person.MISSIONARY).count();
        long missionInTo = toCopy.stream().filter((x) -> x == Person.MISSIONARY).count();

        long cannibalsInFrom = fromCopy.stream().filter((x) -> x == Person.CANNIBAL).count();
        long cannibalsInTo = toCopy.stream().filter((x) -> x == Person.CANNIBAL).count();

        boolean fromCondition = (missionInFrom >= cannibalsInFrom) || missionInFrom == 0;
        boolean toCondition = (missionInTo >= cannibalsInTo) || missionInTo == 0;
        return fromCondition && toCondition;
    }

    //Swap back from and start if successor is at the right shore
    private State makeSuccessor(List<Person> from, List<Person> to, boolean boatAtStart) {
        if (boatAtStart) {
            List<Person> tmp = from;
            from = to;
            to = tmp;
        }
        return new State(from, to, boatAtStart);
    }
}

enum Person {
    CANNIBAL, MISSIONARY
}