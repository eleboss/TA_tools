
//UID: 3035392775, Igor Afanasyev
import java.util.*;

public class AStarSearch {
    public static void main(String[] args) {
        System.out.println("Enter tiles: ");
        Scanner scanner = new Scanner(System.in);
        int numOfTiles = 9;
        int[] tiles =new int[9];
        for (int i = 0; i < numOfTiles; i++) {
            tiles[i] = scanner.nextInt();
        }
        scanner.close();

//        int[] tiles = new int[] {7,2,4, 5,0,6, 8,3,1};

        Puzzle puzzle = new Puzzle(tiles);
        Map<Puzzle, Puzzle> from = puzzle.aStar();
        Puzzle state = new Puzzle(Puzzle.goal);
        List<Puzzle> solutionPath = new ArrayList<>();

        while (state != null) {
            solutionPath.add(0, state);
            state = from.get(state);
        }

        System.out.println((solutionPath.size() - 1) + " moves made");
        solutionPath.forEach(System.out::println);

    }
}

class Puzzle {

    private final int[] tiles;

    public static final int[] goal = {0, 1, 2, 3, 4, 5, 6, 7, 8};

    private int gScore = Integer.MAX_VALUE;

    private int fScore;

    public Puzzle(int[] tiles) {
        this.tiles = tiles;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Puzzle puzzle = (Puzzle) o;
        return Arrays.equals(tiles, puzzle.tiles);
    }

    @Override
    public int hashCode() {
        return Arrays.hashCode(tiles);
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < tiles.length; i++) {
            builder.append(tiles[i]);
            builder.append(' ');
            if (i % 3 == 2) builder.append(System.lineSeparator());
        }
        return builder.toString();
    }

    public Map<Puzzle, Puzzle> aStar() {
        Map<Puzzle, Puzzle> from = new HashMap<>();
        PriorityQueue<Puzzle> open = new PriorityQueue<>(Comparator.comparingInt(Puzzle::getfScore));
        Set <Puzzle> closed = new HashSet<>();
        Puzzle start = this;
        start.gScore = 0;
        start.fScore = start.gScore + start.heuristic();
        open.add(start);
        boolean goalReached = false;
        while (!open.isEmpty()) {
            Puzzle current = open.poll();
            closed.add(current);
            if (current.isGoal()) {
                goalReached = true;
                break;
            }
            for (Puzzle successor : current.getSuccessors()) {
                if (closed.contains(successor)) {
                    continue;
                }
                int tmpGScore = current.gScore + 1;
                if (open.contains(successor)) {
                    List<Puzzle> openList = new ArrayList<>(open);
                    Puzzle sameState = openList.get(openList.indexOf(successor));
                    if (sameState.gScore <= tmpGScore) {
                        continue;
                    }
                    //remove less efficient
                    open.remove(sameState);
                }

                if (!open.contains(successor)) {
                    successor.gScore = tmpGScore;
                    //Successor is key, as current has multiple successors and key needs to be unique
                    from.put(successor, current);
                    successor.fScore = successor.gScore + successor.heuristic();
                    open.add(successor);
                }
            }
        }

        if (goalReached) return from;
        return null;


    }

    private int heuristic() {
        // number of misplaced tiles
        int h1 = this.numOfMisplacedTiles();
        int h2 = this.manhattanDistance();
        return Math.max(h1, h2);
    }

    public int numOfMisplacedTiles() {
        int count = 0;
        for (int i = 0; i < tiles.length; i++) {
            if (tiles[i] != Puzzle.goal[i]) {
                count++;
            }
        }
        return count;
    }

    public int manhattanDistance() {
        int distance = 0;
        for (int i = 0; i < tiles.length; i++) {
            //Do not count empty tile for heuristic to be admissible
            if (tiles[i] == 0) {
                continue;
            }
            int rowDistance = Math.abs((tiles[i] / 3) - (i / 3));
            int colDistance = Math.abs((tiles[i] % 3) - (i % 3));
            distance += rowDistance + colDistance;
        }
        return distance;
    }

    public int getfScore() {
        return fScore;
    }

    public boolean isGoal() {
        return Arrays.equals(this.tiles, Puzzle.goal);
    }

    public List<Puzzle> getSuccessors() {

        int zeroIdx = this.zeroIdx();
        int zeroRowIndex = zeroIdx / 3;
        int zeroColIndex = zeroIdx % 3;

        List<Puzzle> successors = new ArrayList<>();

        //can move 0 up
        if (zeroRowIndex > 0) {
            Puzzle successor = this.swapTile(zeroIdx, zeroIdx - 3);
            successors.add(successor);
        }
        //can move 0 down
        if (zeroRowIndex < 2) {
            Puzzle successor = this.swapTile(zeroIdx, zeroIdx + 3);
            successors.add(successor);
        }
        //can move 0 left
        if (zeroColIndex > 0) {
            Puzzle successor = this.swapTile(zeroIdx, zeroIdx - 1);
            successors.add(successor);
        }
        //can move 0 right
        if (zeroColIndex < 2) {
            Puzzle successor = this.swapTile(zeroIdx, zeroIdx + 1);
            successors.add(successor);
        }

        return successors;
    }

    private int zeroIdx() {
        int idx = -1;
        for (int i = 0; i < tiles.length; i++) {
            if (tiles[i] == 0) idx = i;
        }
        return idx;
    }

    private Puzzle swapTile(int zeroIdx, int neighbour) {
        int[] tileCopy = Arrays.copyOf(this.tiles, this.tiles.length);
        int temp = tileCopy[zeroIdx];
        tileCopy[zeroIdx] = tileCopy[neighbour];
        tileCopy[neighbour] = temp;
        return new Puzzle(tileCopy);

    }

}
