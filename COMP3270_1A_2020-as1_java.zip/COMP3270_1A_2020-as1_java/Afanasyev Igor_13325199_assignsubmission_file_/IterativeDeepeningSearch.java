

//UID: 3035392775, Igor Afanasyev
import java.util.*;

public class IterativeDeepeningSearch {
    public static void main(String[] args) {
        System.out.println("Enter tiles: ");
        Scanner scanner = new Scanner(System.in);
        int numOfTiles = 9;
        int[][] tiles = new int[3][3];
        for (int i = 0; i < numOfTiles; i++) {
            tiles[i / 3][i % 3] = scanner.nextInt();
        }
        scanner.close();
//        int[][] tiles = {{7,2,4}, {5,0,6}, {8,3,1}};

        Puzzle puzzle = new Puzzle(tiles);
        ids(puzzle);

    }

    private static void ids(Puzzle puzzle) {
        int i = 1;
        while (true) {
            Result result = puzzle.solve(i);
            if (result == Result.SUCCESS || result == Result.LIMIT) {
                puzzle.printSolution();
                break;
            }
            i++;
        }
    }
}

enum Result {
    SUCCESS, LIMIT, DEPTH
}

class Puzzle {

    private static Puzzle solution;

    private final static int MAX_NODES = 1_000_000;

    private final int[][] tiles;
    private final int[][] goal = {{0, 1, 2}, {3, 4, 5}, {6, 7, 8}};

    private Puzzle parent = null;

    private int expandedNodes = 0;

   private int nodeDepth = 0;


    public Puzzle(int[][] tiles) {
        this.tiles = tiles;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Puzzle puzzle = (Puzzle) o;
        return Arrays.deepEquals(this.tiles, puzzle.tiles);
    }

    @Override
    public int hashCode() {
        return Arrays.deepHashCode(tiles);
    }


    public String toString() {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                builder.append(tiles[i][j]);
                builder.append(' ');
            }
            builder.append(System.lineSeparator());
        }
        return builder.toString();
    }


    public Result solve(int limit) {
        Deque<Puzzle> stack = new ArrayDeque<>();
        Set<Puzzle> visited = new HashSet<>();
        stack.push(this);
        Result result = Result.DEPTH;
        expandedNodes = 0;
        while (!stack.isEmpty()) {
            expandedNodes++;
            Puzzle current = stack.pop();
            visited.add(current);
            if (visited.size() == Puzzle.MAX_NODES) {
                System.out.println("LIMIT");
                result = Result.LIMIT;
                break;
            }
            if (current.isGoal()) {
                Puzzle.solution = current;
                result = Result.SUCCESS;
                break;
            }

            if (current.nodeDepth >= limit) {
                continue;
            }

            for (Puzzle successor : current.getSuccessors()) {
                if (!visited.contains(successor)) {
                    successor.nodeDepth = current.nodeDepth + 1;
                    successor.setParent(current);
                    stack.push(successor);
                }
            }
        }

        return result;
    }

    private Puzzle getParent() {
        return parent;
    }

    private void setParent(Puzzle parent) {
        this.parent = parent;
    }



    public boolean isGoal() {
        return Arrays.deepEquals(this.tiles, goal);
    }

    private List<Puzzle> getSuccessors() {

        //Record node expansion at getting successors
        int zeroIdx = this.findZero();
        int zeroRowIndex = zeroIdx / 3;
        int zeroColIndex = zeroIdx % 3;

        List<Puzzle> successors = new ArrayList<>();

        //can move 0 up
        if (zeroRowIndex > 0) {
            Puzzle successor = this.swapTile(zeroIdx, zeroIdx - 3);
            successors.add(successor);
        }
        //can move 0 down
        if (zeroRowIndex < 2) {
            Puzzle successor = this.swapTile(zeroIdx, zeroIdx + 3);
            successors.add(successor);
        }
        //can move 0 left
        if (zeroColIndex > 0) {
            Puzzle successor = this.swapTile(zeroIdx, zeroIdx - 1);
            successors.add(successor);
        }
        //can move 0 right
        if (zeroColIndex < 2) {
            Puzzle successor = this.swapTile(zeroIdx, zeroIdx + 1);
            successors.add(successor);
        }

        return successors;
    }

    private int findZero() {
        int zeroRowIndex = -1;
        int zeroColIndex = -1;
        for (int i = 0; i < tiles.length; i++) {
            for (int j = 0; j < tiles[i].length; j++) {
                if (tiles[i][j] == 0) {
                    zeroRowIndex = i;
                    zeroColIndex = j;
                }
            }
        }
        return (zeroRowIndex * 3) + zeroColIndex;
    }

    private Puzzle swapTile(int zeroIdx, int neighbour) {
        int[][] tileCopy = new int[3][3];
        for (int i = 0; i < 3; i++) {
            tileCopy[i] = Arrays.copyOf(this.tiles[i], 3);
        }
        int temp = tileCopy[zeroIdx / 3][zeroIdx % 3];
        tileCopy[zeroIdx / 3][zeroIdx % 3] = tileCopy[neighbour / 3][neighbour % 3];
        tileCopy[neighbour / 3][neighbour % 3] = temp;
        return new Puzzle(tileCopy);
    }

    public void printSolution() {
        List<String> solutionPath = new ArrayList<>();
        Puzzle node = Puzzle.solution;
        while (node != null) {
            solutionPath.add(0, node.toString());
            node = node.getParent();
        }
        //No need to count input state
        System.out.println((solutionPath.size() - 1) + " moves made");
        for (String element : solutionPath) {
            System.out.println(element);
        }
    }

    public int getExpandedNodesCount() {
        return expandedNodes;
    }

}
