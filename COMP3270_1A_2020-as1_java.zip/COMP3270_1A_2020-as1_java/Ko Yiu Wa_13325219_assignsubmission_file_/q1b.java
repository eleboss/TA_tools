//Manhattan-------------------------------------------------------------------
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner ss = new Scanner(System.in);
		System.out.println("Enter top left tile");
		int topleft = ss.nextInt();
		System.out.println("Enter top middle tile");
		int topmiddle = ss.nextInt();
		System.out.println("Enter top right tile");
		int topright = ss.nextInt();
		System.out.println("Enter middle left tile");
		int middleleft = ss.nextInt();
		System.out.println("Enter middle middle tile");
		int middlemiddle = ss.nextInt();
		System.out.println("Enter middle right tile");
		int middleright = ss.nextInt();
		System.out.println("Enter bottom left tile");
		int bottomleft = ss.nextInt();
		System.out.println("Enter bottom middle tile");
		int bottommiddle = ss.nextInt();
		System.out.println("Enter bottom right tile");
		int bottomright = ss.nextInt();
		
		ArrayList<Integer> initialization = new ArrayList<Integer>();
		initialization.add(topleft);
		initialization.add(topmiddle);
		initialization.add(topright);
		initialization.add(middleleft);
		initialization.add(middlemiddle);
		initialization.add(middleright);
		initialization.add(bottomleft);
		initialization.add(bottommiddle);
		initialization.add(bottomright);
		Puzzle puzzle = new Puzzle(initialization);
		Node node = new Node(puzzle, null);
		Traverse tree = new Traverse(node, 0);
		int result = tree.heuristic();
		if (result == 2) {
			System.out.println("Result found");
			tree.printpath();
		}
	}

}

//----------------------------------------------------------------------------

import java.util.ArrayList;

public class Node {
	
	Puzzle puzzle;
	Puzzle temppuzzle1;
	Puzzle temppuzzle2;
	Puzzle temppuzzle3;
	Puzzle temppuzzle4;
	Node parent;
	Node one;
	Node two;
	Node three;
	Node four;
	
	ArrayList<Node> children = new ArrayList<Node>();
	
	public Node(Puzzle puzzle, Node parent) {
		this.puzzle = puzzle;
		this.temppuzzle1 = new Puzzle(puzzle.initialize);
		this.temppuzzle2 = new Puzzle(puzzle.initialize);
		this.temppuzzle3 = new Puzzle(puzzle.initialize);
		this.temppuzzle4 = new Puzzle(puzzle.initialize);
		this.parent = parent;
	}
	
	public void generateNode() {
		if (puzzle.empty.left!=null) {
			int tempnum = temppuzzle1.empty.number;
			int tempx = temppuzzle1.empty.xcoor;
			int tempy = temppuzzle1.empty.ycoor;
			temppuzzle1.empty.number = temppuzzle1.empty.left.number;
			temppuzzle1.empty.xcoor = temppuzzle1.empty.left.xcoor;
			temppuzzle1.empty.ycoor = temppuzzle1.empty.left.ycoor;
			temppuzzle1.empty.left.number = tempnum;
			temppuzzle1.empty.left.xcoor = tempx;
			temppuzzle1.empty.left.ycoor = tempy;
			ArrayList<Integer> templist = new ArrayList<Integer>();
			for (int i = 0; i<9; i++) {
				int temp = temppuzzle1.tilelist.get(i).number;
				templist.add(temp);
			}
			temppuzzle1.initialize = templist;
			for (int i = 0; i<9; i++) {
				if (temppuzzle1.tilelist.get(i).number == 0) {
					temppuzzle1.empty = temppuzzle1.tilelist.get(i);
				}
			}
			if (this.parent == null) {
				this.one = new Node(temppuzzle1, this);
			}
			else {
				if (temppuzzle1.checkpuzzle(this.parent.puzzle)) {
					this.one = null;
				}
				else {
					this.one = new Node(temppuzzle1, this);
				}
			}	
		}
		else {
			this.one = null;
		}
		if (puzzle.empty.right!=null) {
			int tempnum = temppuzzle2.empty.number;
			int tempx = temppuzzle2.empty.xcoor;
			int tempy = temppuzzle2.empty.ycoor;
			temppuzzle2.empty.number = temppuzzle2.empty.right.number;
			temppuzzle2.empty.xcoor = temppuzzle2.empty.right.xcoor;
			temppuzzle2.empty.ycoor = temppuzzle2.empty.right.ycoor;
			temppuzzle2.empty.right.number = tempnum;
			temppuzzle2.empty.right.xcoor = tempx;
			temppuzzle2.empty.right.ycoor = tempy;
			ArrayList<Integer> templist = new ArrayList<Integer>();
			for (int i = 0; i<9; i++) {
				int temp = temppuzzle2.tilelist.get(i).number;
				templist.add(temp);
			}
			temppuzzle2.initialize = templist;
			for (int i = 0; i<9; i++) {
				if (temppuzzle2.tilelist.get(i).number == 0) {
					temppuzzle2.empty = temppuzzle2.tilelist.get(i);
				}
			}
			if (this.parent == null) {
				this.two = new Node(temppuzzle2, this);
			}
			else {
				if (temppuzzle2.checkpuzzle(this.parent.puzzle)) {
					this.two = null;
				}
				else {
					this.two = new Node(temppuzzle2, this);
				}
			}
		}
		else {
			this.two = null;
		}
		if (puzzle.empty.upper!=null) {
			int tempnum = temppuzzle3.empty.number;
			int tempx = temppuzzle3.empty.xcoor;
			int tempy = temppuzzle3.empty.ycoor;
			temppuzzle3.empty.number = temppuzzle3.empty.upper.number;
			temppuzzle3.empty.xcoor = temppuzzle3.empty.upper.xcoor;
			temppuzzle3.empty.ycoor = temppuzzle3.empty.upper.ycoor;
			temppuzzle3.empty.upper.number = tempnum;
			temppuzzle3.empty.upper.xcoor = tempx;
			temppuzzle3.empty.upper.ycoor = tempy;
			ArrayList<Integer> templist = new ArrayList<Integer>();
			for (int i = 0; i<9; i++) {
				int temp = temppuzzle3.tilelist.get(i).number;
				templist.add(temp);
			}
			temppuzzle3.initialize = templist;
			for (int i = 0; i<9; i++) {
				if (temppuzzle3.tilelist.get(i).number == 0) {
					temppuzzle3.empty = temppuzzle3.tilelist.get(i);
				}
			}
			if (this.parent == null) {
				this.three = new Node(temppuzzle3, this);
			}
			else {
				if (temppuzzle3.checkpuzzle(this.parent.puzzle)) {
					this.three = null;
				}
				else {
					this.three = new Node(temppuzzle3, this);
				}
			}
		}
		else {
			this.three = null;
		}
		if (puzzle.empty.lower!=null) {
			int tempnum = temppuzzle4.empty.number;
			int tempx = temppuzzle4.empty.xcoor;
			int tempy = temppuzzle4.empty.ycoor;
			temppuzzle4.empty.number = temppuzzle4.empty.lower.number;
			temppuzzle4.empty.xcoor = temppuzzle4.empty.lower.xcoor;
			temppuzzle4.empty.ycoor = temppuzzle4.empty.lower.ycoor;
			temppuzzle4.empty.lower.number = tempnum;
			temppuzzle4.empty.lower.xcoor = tempx;
			temppuzzle4.empty.lower.ycoor = tempy;
			ArrayList<Integer> templist = new ArrayList<Integer>();
			for (int i = 0; i<9; i++) {
				int temp = temppuzzle4.tilelist.get(i).number;
				templist.add(temp);
			}
			temppuzzle4.initialize = templist;
			for (int i = 0; i<9; i++) {
				if (temppuzzle4.tilelist.get(i).number == 0) {
					temppuzzle4.empty = temppuzzle4.tilelist.get(i);
				}
			}
			if (this.parent == null) {
				this.four = new Node(temppuzzle4, this);
			}
			else {
				if (temppuzzle4.checkpuzzle(this.parent.puzzle)) {
					this.four = null;
				}
				else {
					this.four = new Node(temppuzzle4, this);
				}
			}
		}
		else {
			this.four = null;
		}
		this.children.clear();
		this.children.add(four);
		this.children.add(three);
		this.children.add(two);
		this.children.add(one);
	}
	
}

//----------------------------------------------------------------------------

import java.util.ArrayList;

public class Puzzle {
	
	Tiles zero = new Tiles(0);
	Tiles one = new Tiles(1);
	Tiles two = new Tiles(2);
	Tiles three = new Tiles(3);
	Tiles four = new Tiles(4);
	Tiles five = new Tiles(5);
	Tiles six = new Tiles(6);
	Tiles seven = new Tiles(7);
	Tiles eight = new Tiles(8);
	Tiles empty;
	
	ArrayList<Integer> initialize = new ArrayList<Integer>();
	
	ArrayList<Tiles> tilelist = new ArrayList<Tiles>();
	
	public Puzzle(ArrayList<Integer> initial) {
		zero.amend(initial.get(0), returnxcoor(initial.get(0)), returnycoor(initial.get(0)), 0, 0, null, one, null, three);
		one.amend(initial.get(1), returnxcoor(initial.get(1)), returnycoor(initial.get(1)), 1, 0, zero, two, null, four);
		two.amend(initial.get(2), returnxcoor(initial.get(2)), returnycoor(initial.get(2)), 2, 0, one, null, null, five);
		three.amend(initial.get(3), returnxcoor(initial.get(3)), returnycoor(initial.get(3)), 0, 1, null, four, zero, six);
		four.amend(initial.get(4), returnxcoor(initial.get(4)), returnycoor(initial.get(4)), 1, 1, three, five, one, seven);
		five.amend(initial.get(5), returnxcoor(initial.get(5)), returnycoor(initial.get(5)), 2, 1, four, null, two, eight);
		six.amend(initial.get(6), returnxcoor(initial.get(6)), returnycoor(initial.get(6)), 0, 2, null, seven, three, null);
		seven.amend(initial.get(7), returnxcoor(initial.get(7)), returnycoor(initial.get(7)), 1, 2, six, eight, four, null);
		eight.amend(initial.get(8), returnxcoor(initial.get(8)), returnycoor(initial.get(8)), 2, 2, seven, null, five, null);
		tilelist.add(zero);
		tilelist.add(one);
		tilelist.add(two);
		tilelist.add(three);
		tilelist.add(four);
		tilelist.add(five);
		tilelist.add(six);
		tilelist.add(seven);
		tilelist.add(eight);
		this.initialize = initial;
		for (int i = 0; i<9; i++) {
			if (this.tilelist.get(i).number == 0) {
				this.empty = this.tilelist.get(i);
			}
		}
	}
	
	public int Manhattan() {
		int Man = 0;
		for (int i = 0; i<9; i++) {
			Man = Man + tilelist.get(i).Manhattan();
		}
		return Man-empty.Manhattan();
	}
	
	public boolean checkpuzzle(Puzzle puzzle) {
		for (int i = 0; i<9; i++) {
			if (this.tilelist.get(i).number == puzzle.tilelist.get(i).number){	
			}
			else {
				return false;
			}
		}
		return true;
	}
	
	public int returnxcoor(int num) {
		if (num == 0) {
			return 0;
		}
		else if (num == 1) {
			return 1;
		}
		else if (num == 2) {
			return 2;
		}
		else if (num == 3) {
			return 0;
		}
		else if (num == 4) {
			return 1;
		}
		else if (num == 5) {
			return 2;
		}
		else if (num == 6) {
			return 0;
		}
		else if (num == 7) {
			return 1;
		}
		else if (num == 8) {
			return 2;
		}
		else {
			return 0;
		}
	}
	
	public int returnycoor(int num) {
		if (num == 0) {
			return 0;
		}
		else if (num == 1) {
			return 0;
		}
		else if (num == 2) {
			return 0;
		}
		else if (num == 3) {
			return 1;
		}
		else if (num == 4) {
			return 1;
		}
		else if (num == 5) {
			return 1;
		}
		else if (num == 6) {
			return 2;
		}
		else if (num == 7) {
			return 2;
		}
		else if (num == 8) {
			return 2;
		}
		else {
			return 0;
		}
	}
	
}

//----------------------------------------------------------------------------

public class Tiles {
	
	int number;
	int correctnumber;
	int xcoor;
	int ycoor;
	int tilexcoor;
	int tileycoor;
	Tiles left;
	Tiles right;
	Tiles upper;
	Tiles lower;
	
	public Tiles(int cornum) {
		this.correctnumber = cornum;
	}
	
	public boolean checkmatch(){
		if (number==correctnumber){
			return true;
		}
		else {
			return false;
		}
	}
	
	public void amend(int num, int x, int y, int corx, int cory, Tiles left, Tiles right, Tiles upper, Tiles lower) {
		this.number = num;
		this.xcoor = x;
		this.ycoor = y;
		this.tilexcoor = corx;
		this.tileycoor = cory;
		this.left = left;
		this.right = right;
		this.upper = upper;
		this.lower = lower;
	}
	
	public int Manhattan() {
		return(Math.abs(xcoor-tilexcoor)+Math.abs(ycoor-tileycoor));		
	}
	
	public boolean compare(Tiles tile) {
		if (this.number==tile.number) {
			return true;
		}
		else {
			return false;
		}
	}

}

//----------------------------------------------------------------------------

import java.util.ArrayList;
import java.util.Collections;
import java.util.Stack;

public class Traverse {
	
	Node node;
	Node lastnode;
	ArrayList<Puzzle> visited = new ArrayList<Puzzle>();
	int sunkcost;
	
	public Traverse(Node node, int sunkcost) {
		this.node = node;
		this.sunkcost = sunkcost;
	}
	
	public int heuristic() {
		
		Node element = this.node;
		if (element.puzzle.Manhattan() == 0) {
			lastnode = element;
			return 2;
		}
		else {
			int pos = 0;
			ArrayList<Node> nextnodes;
			while (element.puzzle.Manhattan() != 0) {
				if (pos == 10000000) {
					element = element.parent;
					sunkcost = sunkcost + 1;
					nextnodes = element.children;
					pos = this.findmin(element.children, sunkcost, visited);
					if (pos == 10000000) {
					}
					else {
						element = nextnodes.get(pos);
					}
				}
				else {
					visited.add(element.puzzle);
					element.generateNode();
					sunkcost = sunkcost + 1;
					nextnodes = element.children;
					pos = this.findmin(element.children, sunkcost, visited);
					if (pos == 10000000) {
					}
					else {
						element = nextnodes.get(pos);
					}
				}
			}
			lastnode = element;
			return 2;
		}
	}
	
	public int findmin(ArrayList<Node> list, int cost, ArrayList<Puzzle> visited) {
		ArrayList<Integer> intlist = new ArrayList<Integer>();
		for (int i = 0; i<list.size(); i++) {
			if (list.get(i) != null) {
				int ind = 0;
				for (int j = 0; j<visited.size(); j++) {
					if (list.get(i).puzzle.checkpuzzle(visited.get(j))){
						ind = 1;
					}
				}
				if (ind == 1) {
					intlist.add(10000000);
				}
				else {
					intlist.add(list.get(i).puzzle.Manhattan() + cost);
				}
			}
			else {
				intlist.add(10000000);
			}
		}
		if (Collections.min(intlist) == 10000000) {
			return 10000000;
		}
		return intlist.indexOf(Collections.min(intlist));
	}
	
	public void printpath() {
		System.out.println("Path:");
		Stack<Node> stack = new Stack<Node>();
		Node previous = null;
		stack.add(lastnode);
		if (lastnode.parent != null) {
			previous = lastnode.parent;
			stack.add(previous);
			while (previous.parent != null) {
				previous = previous.parent;
				stack.add(previous);
			}
		}
		int moves = stack.size() - 1;
		while (!stack.empty()) {
			Node element = stack.pop();
			for (int i = 0; i<9; i++) {
				System.out.print(element.puzzle.tilelist.get(i).number);
			}
			System.out.println();
		}
		System.out.println("Total moves: " + moves);
	}

}

//Misplaced-------------------------------------------------------------------
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner ss = new Scanner(System.in);
		System.out.println("Enter top left tile");
		int topleft = ss.nextInt();
		System.out.println("Enter top middle tile");
		int topmiddle = ss.nextInt();
		System.out.println("Enter top right tile");
		int topright = ss.nextInt();
		System.out.println("Enter middle left tile");
		int middleleft = ss.nextInt();
		System.out.println("Enter middle middle tile");
		int middlemiddle = ss.nextInt();
		System.out.println("Enter middle right tile");
		int middleright = ss.nextInt();
		System.out.println("Enter bottom left tile");
		int bottomleft = ss.nextInt();
		System.out.println("Enter bottom middle tile");
		int bottommiddle = ss.nextInt();
		System.out.println("Enter bottom right tile");
		int bottomright = ss.nextInt();
		
		ArrayList<Integer> initialization = new ArrayList<Integer>();
		initialization.add(topleft);
		initialization.add(topmiddle);
		initialization.add(topright);
		initialization.add(middleleft);
		initialization.add(middlemiddle);
		initialization.add(middleright);
		initialization.add(bottomleft);
		initialization.add(bottommiddle);
		initialization.add(bottomright);
		Puzzle puzzle = new Puzzle(initialization);
		Node node = new Node(puzzle, null);
		Traverse tree = new Traverse(node, 0);
		int result = tree.heuristic();
		if (result == 2) {
			System.out.println("Result found");
			tree.printpath();
		}
	}

}

//----------------------------------------------------------------------------

import java.util.ArrayList;

public class Node {
	
	Puzzle puzzle;
	Puzzle temppuzzle1;
	Puzzle temppuzzle2;
	Puzzle temppuzzle3;
	Puzzle temppuzzle4;
	Node parent;
	Node one;
	Node two;
	Node three;
	Node four;
	
	ArrayList<Node> children = new ArrayList<Node>();
	
	public Node(Puzzle puzzle, Node parent) {
		this.puzzle = puzzle;
		this.temppuzzle1 = new Puzzle(puzzle.initialize);
		this.temppuzzle2 = new Puzzle(puzzle.initialize);
		this.temppuzzle3 = new Puzzle(puzzle.initialize);
		this.temppuzzle4 = new Puzzle(puzzle.initialize);
		this.parent = parent;
	}
	
	public void generateNode() {
		if (puzzle.empty.left!=null) {
			int tempnum = temppuzzle1.empty.number;
			int tempx = temppuzzle1.empty.xcoor;
			int tempy = temppuzzle1.empty.ycoor;
			temppuzzle1.empty.number = temppuzzle1.empty.left.number;
			temppuzzle1.empty.xcoor = temppuzzle1.empty.left.xcoor;
			temppuzzle1.empty.ycoor = temppuzzle1.empty.left.ycoor;
			temppuzzle1.empty.left.number = tempnum;
			temppuzzle1.empty.left.xcoor = tempx;
			temppuzzle1.empty.left.ycoor = tempy;
			ArrayList<Integer> templist = new ArrayList<Integer>();
			for (int i = 0; i<9; i++) {
				int temp = temppuzzle1.tilelist.get(i).number;
				templist.add(temp);
			}
			temppuzzle1.initialize = templist;
			for (int i = 0; i<9; i++) {
				if (temppuzzle1.tilelist.get(i).number == 0) {
					temppuzzle1.empty = temppuzzle1.tilelist.get(i);
				}
			}
			if (this.parent == null) {
				this.one = new Node(temppuzzle1, this);
			}
			else {
				if (temppuzzle1.checkpuzzle(this.parent.puzzle)) {
					this.one = null;
				}
				else {
					this.one = new Node(temppuzzle1, this);
				}
			}	
		}
		else {
			this.one = null;
		}
		if (puzzle.empty.right!=null) {
			int tempnum = temppuzzle2.empty.number;
			int tempx = temppuzzle2.empty.xcoor;
			int tempy = temppuzzle2.empty.ycoor;
			temppuzzle2.empty.number = temppuzzle2.empty.right.number;
			temppuzzle2.empty.xcoor = temppuzzle2.empty.right.xcoor;
			temppuzzle2.empty.ycoor = temppuzzle2.empty.right.ycoor;
			temppuzzle2.empty.right.number = tempnum;
			temppuzzle2.empty.right.xcoor = tempx;
			temppuzzle2.empty.right.ycoor = tempy;
			ArrayList<Integer> templist = new ArrayList<Integer>();
			for (int i = 0; i<9; i++) {
				int temp = temppuzzle2.tilelist.get(i).number;
				templist.add(temp);
			}
			temppuzzle2.initialize = templist;
			for (int i = 0; i<9; i++) {
				if (temppuzzle2.tilelist.get(i).number == 0) {
					temppuzzle2.empty = temppuzzle2.tilelist.get(i);
				}
			}
			if (this.parent == null) {
				this.two = new Node(temppuzzle2, this);
			}
			else {
				if (temppuzzle2.checkpuzzle(this.parent.puzzle)) {
					this.two = null;
				}
				else {
					this.two = new Node(temppuzzle2, this);
				}
			}
		}
		else {
			this.two = null;
		}
		if (puzzle.empty.upper!=null) {
			int tempnum = temppuzzle3.empty.number;
			int tempx = temppuzzle3.empty.xcoor;
			int tempy = temppuzzle3.empty.ycoor;
			temppuzzle3.empty.number = temppuzzle3.empty.upper.number;
			temppuzzle3.empty.xcoor = temppuzzle3.empty.upper.xcoor;
			temppuzzle3.empty.ycoor = temppuzzle3.empty.upper.ycoor;
			temppuzzle3.empty.upper.number = tempnum;
			temppuzzle3.empty.upper.xcoor = tempx;
			temppuzzle3.empty.upper.ycoor = tempy;
			ArrayList<Integer> templist = new ArrayList<Integer>();
			for (int i = 0; i<9; i++) {
				int temp = temppuzzle3.tilelist.get(i).number;
				templist.add(temp);
			}
			temppuzzle3.initialize = templist;
			for (int i = 0; i<9; i++) {
				if (temppuzzle3.tilelist.get(i).number == 0) {
					temppuzzle3.empty = temppuzzle3.tilelist.get(i);
				}
			}
			if (this.parent == null) {
				this.three = new Node(temppuzzle3, this);
			}
			else {
				if (temppuzzle3.checkpuzzle(this.parent.puzzle)) {
					this.three = null;
				}
				else {
					this.three = new Node(temppuzzle3, this);
				}
			}
		}
		else {
			this.three = null;
		}
		if (puzzle.empty.lower!=null) {
			int tempnum = temppuzzle4.empty.number;
			int tempx = temppuzzle4.empty.xcoor;
			int tempy = temppuzzle4.empty.ycoor;
			temppuzzle4.empty.number = temppuzzle4.empty.lower.number;
			temppuzzle4.empty.xcoor = temppuzzle4.empty.lower.xcoor;
			temppuzzle4.empty.ycoor = temppuzzle4.empty.lower.ycoor;
			temppuzzle4.empty.lower.number = tempnum;
			temppuzzle4.empty.lower.xcoor = tempx;
			temppuzzle4.empty.lower.ycoor = tempy;
			ArrayList<Integer> templist = new ArrayList<Integer>();
			for (int i = 0; i<9; i++) {
				int temp = temppuzzle4.tilelist.get(i).number;
				templist.add(temp);
			}
			temppuzzle4.initialize = templist;
			for (int i = 0; i<9; i++) {
				if (temppuzzle4.tilelist.get(i).number == 0) {
					temppuzzle4.empty = temppuzzle4.tilelist.get(i);
				}
			}
			if (this.parent == null) {
				this.four = new Node(temppuzzle4, this);
			}
			else {
				if (temppuzzle4.checkpuzzle(this.parent.puzzle)) {
					this.four = null;
				}
				else {
					this.four = new Node(temppuzzle4, this);
				}
			}
		}
		else {
			this.four = null;
		}
		this.children.clear();
		this.children.add(four);
		this.children.add(three);
		this.children.add(two);
		this.children.add(one);
	}
	
}

//----------------------------------------------------------------------------

import java.util.ArrayList;
import java.util.Collections;
import java.util.Stack;

public class Traverse {
	
	Node node;
	Node lastnode;
	ArrayList<Puzzle> visited = new ArrayList<Puzzle>();
	int sunkcost;
	
	public Traverse(Node node, int sunkcost) {
		this.node = node;
		this.sunkcost = sunkcost;
	}
	
	public int heuristic() {
		
		Node element = this.node;
		if (element.puzzle.Misplaced() == 0) {
			lastnode = element;
			return 2;
		}
		else {
			int pos = 0;
			ArrayList<Node> nextnodes;
			while (element.puzzle.Misplaced() != 0) {
				if (pos == 10000000) {
					element = element.parent;
					sunkcost = sunkcost + 1;
					nextnodes = element.children;
					pos = this.findmin(element.children, sunkcost, visited);
					if (pos == 10000000) {
					}
					else {
						element = nextnodes.get(pos);
					}
				}
				else {
					visited.add(element.puzzle);
					element.generateNode();
					sunkcost = sunkcost + 1;
					nextnodes = element.children;
					pos = this.findmin(element.children, sunkcost, visited);
					if (pos == 10000000) {
					}
					else {
						element = nextnodes.get(pos);
					}
				}
			}
			lastnode = element;
			return 2;
		}
	}
	
	public int findmin(ArrayList<Node> list, int cost, ArrayList<Puzzle> visited) {
		ArrayList<Integer> intlist = new ArrayList<Integer>();
		for (int i = 0; i<list.size(); i++) {
			if (list.get(i) != null) {
				int ind = 0;
				for (int j = 0; j<visited.size(); j++) {
					if (list.get(i).puzzle.checkpuzzle(visited.get(j))){
						ind = 1;
					}
				}
				if (ind == 1) {
					intlist.add(10000000);
				}
				else {
					intlist.add(list.get(i).puzzle.Misplaced() + cost);
				}
			}
			else {
				intlist.add(10000000);
			}
		}
		if (Collections.min(intlist) == 10000000) {
			return 10000000;
		}
		return intlist.indexOf(Collections.min(intlist));
	}
	
	public void printpath() {
		System.out.println("Path:");
		Stack<Node> stack = new Stack<Node>();
		Node previous = null;
		stack.add(lastnode);
		if (lastnode.parent != null) {
			previous = lastnode.parent;
			stack.add(previous);
			while (previous.parent != null) {
				previous = previous.parent;
				stack.add(previous);
			}
		}
		int moves = stack.size() - 1;
		while (!stack.empty()) {
			Node element = stack.pop();
			for (int i = 0; i<9; i++) {
				System.out.print(element.puzzle.tilelist.get(i).number);
			}
			System.out.println();
		}
		System.out.println("Total moves: " + moves);
	}

}

//----------------------------------------------------------------------------

public class Tiles {
	
	int number;
	int correctnumber;
	int xcoor;
	int ycoor;
	int tilexcoor;
	int tileycoor;
	Tiles left;
	Tiles right;
	Tiles upper;
	Tiles lower;
	
	public Tiles(int cornum) {
		this.correctnumber = cornum;
	}
	
	public boolean checkmatch(){
		if (number==correctnumber){
			return true;
		}
		else {
			return false;
		}
	}
	
	public void amend(int num, int x, int y, int corx, int cory, Tiles left, Tiles right, Tiles upper, Tiles lower) {
		this.number = num;
		this.xcoor = x;
		this.ycoor = y;
		this.tilexcoor = corx;
		this.tileycoor = cory;
		this.left = left;
		this.right = right;
		this.upper = upper;
		this.lower = lower;
	}
	
	public int misplaced() {
		if (Math.abs(xcoor-tilexcoor) + Math.abs(ycoor-tileycoor) > 0) {
			return 1;
		}
		else {
			return 0;
		}
	}
	
	public boolean compare(Tiles tile) {
		if (this.number==tile.number) {
			return true;
		}
		else {
			return false;
		}
	}

}

//----------------------------------------------------------------------------

import java.util.ArrayList;

public class Puzzle {
	
	Tiles zero = new Tiles(0);
	Tiles one = new Tiles(1);
	Tiles two = new Tiles(2);
	Tiles three = new Tiles(3);
	Tiles four = new Tiles(4);
	Tiles five = new Tiles(5);
	Tiles six = new Tiles(6);
	Tiles seven = new Tiles(7);
	Tiles eight = new Tiles(8);
	Tiles empty;
	
	ArrayList<Integer> initialize = new ArrayList<Integer>();
	
	ArrayList<Tiles> tilelist = new ArrayList<Tiles>();
	
	public Puzzle(ArrayList<Integer> initial) {
		zero.amend(initial.get(0), returnxcoor(initial.get(0)), returnycoor(initial.get(0)), 0, 0, null, one, null, three);
		one.amend(initial.get(1), returnxcoor(initial.get(1)), returnycoor(initial.get(1)), 1, 0, zero, two, null, four);
		two.amend(initial.get(2), returnxcoor(initial.get(2)), returnycoor(initial.get(2)), 2, 0, one, null, null, five);
		three.amend(initial.get(3), returnxcoor(initial.get(3)), returnycoor(initial.get(3)), 0, 1, null, four, zero, six);
		four.amend(initial.get(4), returnxcoor(initial.get(4)), returnycoor(initial.get(4)), 1, 1, three, five, one, seven);
		five.amend(initial.get(5), returnxcoor(initial.get(5)), returnycoor(initial.get(5)), 2, 1, four, null, two, eight);
		six.amend(initial.get(6), returnxcoor(initial.get(6)), returnycoor(initial.get(6)), 0, 2, null, seven, three, null);
		seven.amend(initial.get(7), returnxcoor(initial.get(7)), returnycoor(initial.get(7)), 1, 2, six, eight, four, null);
		eight.amend(initial.get(8), returnxcoor(initial.get(8)), returnycoor(initial.get(8)), 2, 2, seven, null, five, null);
		tilelist.add(zero);
		tilelist.add(one);
		tilelist.add(two);
		tilelist.add(three);
		tilelist.add(four);
		tilelist.add(five);
		tilelist.add(six);
		tilelist.add(seven);
		tilelist.add(eight);
		this.initialize = initial;
		for (int i = 0; i<9; i++) {
			if (this.tilelist.get(i).number == 0) {
				this.empty = this.tilelist.get(i);
			}
		}
	}
	
	public int Misplaced() {
		int mis = 0;
		for (int i = 0; i<9; i++) {
			mis = mis + tilelist.get(i).misplaced();
		}
		return mis - empty.misplaced();
	}
	
	public boolean checkpuzzle(Puzzle puzzle) {
		for (int i = 0; i<9; i++) {
			if (this.tilelist.get(i).number == puzzle.tilelist.get(i).number){	
			}
			else {
				return false;
			}
		}
		return true;
	}
	
	public int returnxcoor(int num) {
		if (num == 0) {
			return 0;
		}
		else if (num == 1) {
			return 1;
		}
		else if (num == 2) {
			return 2;
		}
		else if (num == 3) {
			return 0;
		}
		else if (num == 4) {
			return 1;
		}
		else if (num == 5) {
			return 2;
		}
		else if (num == 6) {
			return 0;
		}
		else if (num == 7) {
			return 1;
		}
		else if (num == 8) {
			return 2;
		}
		else {
			return 0;
		}
	}
	
	public int returnycoor(int num) {
		if (num == 0) {
			return 0;
		}
		else if (num == 1) {
			return 0;
		}
		else if (num == 2) {
			return 0;
		}
		else if (num == 3) {
			return 1;
		}
		else if (num == 4) {
			return 1;
		}
		else if (num == 5) {
			return 1;
		}
		else if (num == 6) {
			return 2;
		}
		else if (num == 7) {
			return 2;
		}
		else if (num == 8) {
			return 2;
		}
		else {
			return 0;
		}
	}
	
}
