
public class Main {

	public static void main(String[] args) {
		LeftShore left = new LeftShore();
		RightShore right = new RightShore();
		Ocean ocean = new Ocean(left, right);
		Node node = new Node(ocean, null, 0);
		Traverse tree = new Traverse(node, 11);
		int result = tree.DFS();
		if (result == 2) {
			System.out.println("Result found");
			tree.printpath();
		}
	}

}

//-----------------------------------------------------------------------------

import java.util.ArrayList;
import java.util.Stack;

public class Traverse {
	
	Node node;
	Node lastnode;
	int depth;
	
	ArrayList<Ocean> leftvisited = new ArrayList<Ocean>();
	ArrayList<Ocean> rightvisited = new ArrayList<Ocean>();
	
	public Traverse(Node node, int depth) {
		this.node = node;
		this.depth = depth;
	}
	
	public int DFS() {
		Stack<Node> stack = new Stack<Node>();
		stack.add(node);
		while(!stack.empty()) {
			Node element = stack.pop();
			if (element.ocean.shippos == "L") {
				leftvisited.add(element.ocean);
			}
			else {
				rightvisited.add(element.ocean);
			}
			if (element.ocean.left.checkstatus() == true) {
				lastnode = element;
				return 2;
			}
			else {
				element.generateNode();
				for (Node nextnode : element.children) {
					if (nextnode.depth > this.depth) {
					}
					else if (this.check(nextnode.ocean) == false) {
					}
					else {
						stack.add(nextnode);
					}
				}
			}
		}
		return 1;
	}
	
	public void printpath() {
		System.out.println("Path:");
		Stack<Node> stack = new Stack<Node>();
		Node previous = null;
		stack.add(lastnode);
		if (lastnode.parent != null) {
			previous = lastnode.parent;
			stack.add(previous);
			while (previous.parent != null) {
				previous = previous.parent;
				stack.add(previous);
			}
		}
		int moves = stack.size() - 1;
		while (!stack.empty()) {
			Node element = stack.pop();
			System.out.println("Left Can: " + element.ocean.left.cannibals + "; Left Mis: " + element.ocean.left.missionaries + "; Right Can: " + element.ocean.right.cannibals + "; Right Mis: " + element.ocean.right.missionaries);
		}
		System.out.println("Total moves: " + moves);
	}
	
	public boolean check(Ocean ocean) {
		if (ocean.shippos == "L") {
			for (int i = 0; i<leftvisited.size(); i++) {
				if (ocean.check(leftvisited.get(i)) == true) {
					return false;
				}
			}
		}
		else {
			for (int i = 0; i<rightvisited.size(); i++) {
				if (ocean.check(rightvisited.get(i)) == true) {
					return false;
				}
			}
		}
		return true;
	}

}

//-----------------------------------------------------------------------------

public class RightShore {
	
	int cannibals;
	int missionaries;
	
	public RightShore() {
		this.cannibals = 3;
		this.missionaries = 3;
	}
	
	public RightShore(int can, int mis) {
		this.cannibals = can;
		this.missionaries = mis;
	}
	
	public boolean shiparrive(int can, int mis) {
		int newcan = cannibals + can;
		int newmis = missionaries + mis;
		if (newcan > 3 || newmis > 3) {
			return false;
		}
		else if (newcan > newmis && newmis > 0) {
			return false;
		}
		else {
			cannibals = newcan;
			missionaries = newmis;
			return true;
		}
	}
	
	public boolean shipleave(int can, int mis) {
		int newcan = cannibals - can;
		int newmis = missionaries - mis;
		if (newcan < 0 || newmis < 0) {
			return false;
		}
		else if (newcan > newmis && newmis > 0) {
			return false;
		}
		else {
			cannibals = newcan;
			missionaries = newmis;
			return true;
		}
	}
	
	public boolean checkstatus() {
		if (cannibals == 0 && missionaries == 0) {
			return true;
		}
		else {
			return false;
		}
	}

}

//-----------------------------------------------------------------------------

public class Ocean {
	
	LeftShore left;
	RightShore right;
	String shippos;
	
	public Ocean(LeftShore left, RightShore right) {
		this.left = left;
		this.right = right;
		this.shippos = "R";
	}
	
	public Ocean(int leftcan, int leftmis, int rightcan, int rightmis, String shippos) {
		this.left = new LeftShore(leftcan, leftmis);
		this.right = new RightShore(rightcan, rightmis);
		this.shippos = shippos;
	}
	
	public boolean transportleft(int can, int mis) {
		boolean a = left.shiparrive(can, mis);
		boolean b = right.shipleave(can, mis);
		if (a == true && b == true) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public boolean transportright(int can, int mis) {
		boolean a = right.shiparrive(can, mis);
		boolean b = left.shipleave(can, mis);
		if (a == true && b == true) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public boolean check(Ocean ocean1) {
		if (ocean1.left.cannibals != this.left.cannibals) {
			return false;
		}
		else if (ocean1.right.cannibals != this.right.cannibals) {
			return false;
		}
		else if (ocean1.left.missionaries != this.left.missionaries) {
			return false;
		}
		else if (ocean1.right.missionaries != this.right.missionaries) {
			return false;
		}
		return true;
	}

}

//-----------------------------------------------------------------------------

import java.util.ArrayList;

public class Node {
	
	Ocean ocean;
	Ocean ocean0;
	Ocean ocean1;
	Ocean ocean2;
	Ocean ocean3;
	Ocean ocean4;
	int depth;
	Node parent;
	Node one;
	Node two;
	Node three;
	Node four;
	
	ArrayList<Node> children = new ArrayList<Node>();
	
	public Node(Ocean ocean, Node parent, int depth) {
		this.ocean = ocean;
		this.parent = parent;
		this.depth = depth;
	}
	
	public void generateNode() {
		if (ocean.shippos == "L") {
			ocean0 = new Ocean(ocean.left.cannibals, ocean.left.missionaries, ocean.right.cannibals, ocean.right.missionaries, "R");
			boolean a = ocean0.transportright(0, 1);
			if (a == true) {
				Node newnode = new Node(ocean0, this, depth +1);
				children.add(newnode);
			}
			ocean1 = new Ocean(ocean.left.cannibals, ocean.left.missionaries, ocean.right.cannibals, ocean.right.missionaries, "R");
			boolean b = ocean1.transportright(1, 0);
			if (b == true) {
				Node newnode = new Node(ocean1, this, depth +1);
				children.add(newnode);
			}
			ocean2 = new Ocean(ocean.left.cannibals, ocean.left.missionaries, ocean.right.cannibals, ocean.right.missionaries, "R");
			boolean c = ocean2.transportright(1, 1);
			if (c == true) {
				Node newnode = new Node(ocean2, this, depth +1);
				children.add(newnode);
			}
			ocean3 = new Ocean(ocean.left.cannibals, ocean.left.missionaries, ocean.right.cannibals, ocean.right.missionaries, "R");
			boolean d = ocean3.transportright(0, 2);
			if (d == true) {
				Node newnode = new Node(ocean3, this, depth +1);
				children.add(newnode);
			}
			ocean4 = new Ocean(ocean.left.cannibals, ocean.left.missionaries, ocean.right.cannibals, ocean.right.missionaries, "R");
			boolean e = ocean4.transportright(2, 0);
			if (e == true) {
				Node newnode = new Node(ocean4, this, depth +1);
				children.add(newnode);
			}
		}
		if (ocean.shippos == "R") {
			ocean0 = new Ocean(ocean.left.cannibals, ocean.left.missionaries, ocean.right.cannibals, ocean.right.missionaries, "L");
			boolean a = ocean0.transportleft(0, 1);
			if (a == true) {
				Node newnode = new Node(ocean0, this, depth +1);
				children.add(newnode);
			}
			ocean1 = new Ocean(ocean.left.cannibals, ocean.left.missionaries, ocean.right.cannibals, ocean.right.missionaries, "L");
			boolean b = ocean1.transportleft(1, 0);
			if (b == true) {
				Node newnode = new Node(ocean1, this, depth +1);
				children.add(newnode);
			}
			ocean2 = new Ocean(ocean.left.cannibals, ocean.left.missionaries, ocean.right.cannibals, ocean.right.missionaries, "L");
			boolean c = ocean2.transportleft(1, 1);
			if (c == true) {
				Node newnode = new Node(ocean2, this, depth +1);
				children.add(newnode);
			}
			ocean3 = new Ocean(ocean.left.cannibals, ocean.left.missionaries, ocean.right.cannibals, ocean.right.missionaries, "L");
			boolean d = ocean3.transportleft(0, 2);
			if (d == true) {
				Node newnode = new Node(ocean3, this, depth +1);
				children.add(newnode);
			}
			ocean4 = new Ocean(ocean.left.cannibals, ocean.left.missionaries, ocean.right.cannibals, ocean.right.missionaries, "L");
			boolean e = ocean4.transportleft(2, 0);
			if (e == true) {
				Node newnode = new Node(ocean4, this, depth +1);
				children.add(newnode);
			}
		}
	}
}

//-----------------------------------------------------------------------------

public class LeftShore {
	
	int cannibals;
	int missionaries;
	
	public LeftShore() {
		this.cannibals = 0;
		this.missionaries = 0;
	}
	
	public LeftShore(int can, int mis) {
		this.cannibals = can;
		this.missionaries = mis;
	}
	
	public boolean shiparrive(int can, int mis) {
		int newcan = cannibals + can;
		int newmis = missionaries + mis;
		if (newcan > 3 || newmis > 3) {
			return false;
		}
		else if (newcan > newmis && newmis > 0) {
			return false;
		}
		else {
			cannibals = newcan;
			missionaries = newmis;
			return true;
		}
	}
	
	public boolean shipleave(int can, int mis) {
		int newcan = cannibals - can;
		int newmis = missionaries - mis;
		if (newcan < 0 || newmis < 0) {
			return false;
		}
		else if (newcan > newmis && newmis > 0) {
			return false;
		}
		else {
			cannibals = newcan;
			missionaries = newmis;
			return true;
		}
	}
	
	public boolean checkstatus() {
		if (cannibals == 3 && missionaries == 3) {
			return true;
		}
		else {
			return false;
		}
	}

}
