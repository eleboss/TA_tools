import java.util.ArrayList;
import java.util.Scanner;

public class q1 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String s = in.nextLine();
        Node start = new Node(s, null, null, 0, Node.generateAvailableActions(s), new ArrayList<>());
        int maxDepth = 0;
        while (true){
            boolean result = Node.checkNode(maxDepth, start);
            if (result) return;
            System.out.println(maxDepth);
            maxDepth++;
            if (Node.getNodes() == 1_000_000) System.out.println("Reached 1000000 nodes, no more will be created");
            Node.setNodes(1);
        }
    }
}

enum Action{
    UP,
    RIGHT,
    DOWN,
    LEFT
}

class Node{
    private String state;
    private Node parent;
    private Action action;
    private int depth;
    private Action[] availableActions;
    private ArrayList<String> visited;
    private static int nodes;

    public Node(String state, Node parent, Action action, int depth, Action[] availableActions, ArrayList<String> visited){
        this.state = state;
        this.parent = parent;
        this.action = action;
        this.depth = depth;
        this.availableActions = availableActions;
        this.visited = visited;
        nodes++;
    }

    public static String stateAfterAction(String state, Action action){
        String newState = "";
        int currentPositionZero = state.indexOf('0');
        switch (action){
            case UP:
                newState = state.substring(0, currentPositionZero - 3) + '0' + state.substring(currentPositionZero - 2, currentPositionZero) + state.charAt(currentPositionZero - 3) + state.substring(currentPositionZero + 1);
                break;
            case RIGHT:
                newState = state.substring(0, currentPositionZero) + state.charAt(currentPositionZero + 1) + '0' + state.substring(currentPositionZero + 2);
                break;
            case LEFT:
                newState = state.substring(0, currentPositionZero -1) + '0' + state.charAt(currentPositionZero - 1) + state.substring(currentPositionZero + 1);
                break;
            case DOWN:
                newState = state.substring(0, currentPositionZero) + state.charAt(currentPositionZero + 3) + state.substring(currentPositionZero + 1, currentPositionZero + 3) + '0';
                if (currentPositionZero != 5) newState += state.substring(currentPositionZero + 4);
                break;
        }
        return newState;
    }

    public static int getNodes() {
        return nodes;
    }

    public void setState(String state) {
        this.state = state;
    }

    public void setParent(Node parent) {
        this.parent = parent;
    }

    public void setAction(Action action) {
        this.action = action;
    }

    public void setDepth(int depth) {
        this.depth = depth;
    }

    public void setAvailableActions(Action[] availableActions) {
        this.availableActions = availableActions;
    }

    public void setVisited(ArrayList<String> visited) {
        this.visited = visited;
    }

    public static void setNodes(int nodes) {
        Node.nodes = nodes;
    }

    public String getState() {
        return state;
    }

    public Node getParent() {
        return parent;
    }

    public Action getAction() {
        return action;
    }

    public int getDepth() {
        return depth;
    }

    public Action[] getAvailableActions() {
        return availableActions;
    }

    public ArrayList<String> getVisited() {
        return visited;
    }

    public static Action[] generateAvailableActions(String state){
        int availableMoves = 0;
        int currentPositionZero = state.indexOf('0');
        if (currentPositionZero > 2) availableMoves += 1;
        if ((currentPositionZero+1) % 3 != 0) availableMoves += 2;
        if (currentPositionZero < 6) availableMoves += 4;
        if (currentPositionZero % 3 != 0) availableMoves += 8;
        switch (availableMoves){
            case 3:
                return new Action[]{Action.UP, Action.RIGHT};
            case 6:
                return new Action[]{Action.RIGHT, Action.DOWN};
            case 7:
                return new Action[]{Action.UP, Action.RIGHT, Action.DOWN};
            case 9:
                return new Action[]{Action.UP, Action.LEFT};
            case 11:
                return new Action[]{Action.UP, Action.RIGHT, Action.LEFT};
            case 12:
                return new Action[]{Action.DOWN, Action.LEFT};
            case 13:
                return new Action[]{Action.UP, Action.DOWN, Action.LEFT};
            case 14:
                return new Action[]{Action.RIGHT, Action.DOWN, Action.LEFT};
            case 15:
                return new Action[]{Action.UP, Action.RIGHT, Action.DOWN, Action.LEFT};
            default:
                return null;
        }
    }

    @Override
    public String toString() {
        return this.state;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Node node = (Node) o;
        return ((Node) o).state.equals(this.state);
    }

    @Override
    public int hashCode() {
        return Integer.parseInt(this.toString());
    }

    public static boolean checkNode(int maxDepth, Node parent) {
        if (parent.getState().equals("012345678")) {
            System.out.println();
            System.out.println("Solution was found, it has " + (parent.visited.size() + 1) + " moves and detailed steps are below: ");
            for(String visited: parent.getVisited()){
                System.out.println(visited.substring(0, 3));
                System.out.println(visited.substring(3, 6));
                System.out.println(visited.substring(6, 9));
                System.out.println();
            }
            System.out.println(parent.getState().substring(0, 3));
            System.out.println(parent.getState().substring(3, 6));
            System.out.println(parent.getState().substring(6, 9));
            return true;
        }
        else
            if (parent.getDepth() == maxDepth) {
                return false;
            }
            else {
                ArrayList<String> newVisited = new ArrayList<>(parent.getVisited());
                newVisited.add(parent.getState());
                for (Action action: parent.getAvailableActions()){
                    if (Node.nodes == 1_000_000) {
                        return false;
                    }
                    String childState = Node.stateAfterAction(parent.getState(), action);
                    if (!newVisited.contains(childState)) {
                        Node child = new Node(childState, parent, action, parent.getDepth() + 1, Node.generateAvailableActions(childState), newVisited);
                        boolean result = Node.checkNode(maxDepth, child);
                        if (result) {
                            return true;
                        } else if (Node.nodes == 1_000_000) return false;
                    }
                }
            }
            return false;
    }
}
