import java.util.ArrayList;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class q2 {
    static boolean findPath(int maxDepth, NodeA start){
        TreeMap<Integer, NodeA> nodes = new TreeMap<>();
        nodes.put(start.getA(), start);
        while (NodeA.getNodes() != 1_000_000){
            NodeA next = null;
            int best = Integer.MAX_VALUE;
            for (Map.Entry<Integer, NodeA> entry: nodes.entrySet()){
                NodeA node = entry.getValue();
                if (!node.isChildrenExpanded() && node.getDepth() < maxDepth && node.getA() < best){
                    next = node;
                    best = node.getA();
                }
            }
            if (next != null){
                ArrayList<String> newVisited = new ArrayList<>(next.getVisited());
                newVisited.add(next.getState());
                for (ActionA action: next.getAvailableActions()){
                    String childState = NodeA.stateAfterAction(next.getState(), action);
                    if (!newVisited.contains(childState)) {
                        nodes.put(NodeA.getHeuristic(childState), new NodeA(childState, next, action, next.getDepth() + 1, NodeA.generateAvailableActions(childState), newVisited, NodeA.getHeuristic(childState)));
                    }
                }
                next.setChildrenExpanded(true);
                if (next.getState().equals("012345678")) {
                    System.out.println();
                    System.out.println("Solution was found, it has " + (next.getVisited().size() + 1) + " moves and detailed steps are below: ");
                    for(String visited: next.getVisited()){
                        System.out.println(visited.substring(0, 3));
                        System.out.println(visited.substring(3, 6));
                        System.out.println(visited.substring(6, 9));
                        System.out.println();
                    }
                    System.out.println(next.getState().substring(0, 3));
                    System.out.println(next.getState().substring(3, 6));
                    System.out.println(next.getState().substring(6, 9));
                    return true;
                }
            } else {
                return false;
            }
        }
        return false;
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String s = in.nextLine();
        int maxDepth = 0;
        while (true){
            boolean result = findPath(maxDepth, new NodeA(s, null, null, 0, NodeA.generateAvailableActions(s), new ArrayList<>(), NodeA.getHeuristic(s)));
            if (result) return;
            System.out.println("Depth explored: " + maxDepth);
            maxDepth++;
            if (NodeA.getNodes() == 1_000_000) System.out.println("Reached 1000000 nodes, no more will be created");
            else System.out.println("Number of nodes expanded on this depth: " + NodeA.getNodes());
            NodeA.setNodes(1);
        }
    }
}

enum ActionA{
    UP,
    RIGHT,
    DOWN,
    LEFT
}

class NodeA{
    private String state;
    private NodeA parent;
    private ActionA action;
    private int depth;
    private ActionA[] availableActions;
    private ArrayList<String> visited;
    private boolean childrenExpanded;
    private static int nodes;
    private int A;

    public NodeA(String state, NodeA parent, ActionA action, int depth, ActionA[] availableActions, ArrayList<String> visited, int A){
        this.state = state;
        this.parent = parent;
        this.action = action;
        this.depth = depth;
        this.availableActions = availableActions;
        this.visited = visited;
        this.A = A;
        nodes++;
    }

    public static String stateAfterAction(String state, ActionA action){
        String newState = "";
        int currentPositionZero = state.indexOf('0');
        switch (action){
            case UP:
                newState = state.substring(0, currentPositionZero - 3) + '0' + state.substring(currentPositionZero - 2, currentPositionZero) + state.charAt(currentPositionZero - 3) + state.substring(currentPositionZero + 1);
                break;
            case RIGHT:
                newState = state.substring(0, currentPositionZero) + state.charAt(currentPositionZero + 1) + '0' + state.substring(currentPositionZero + 2);
                break;
            case LEFT:
                newState = state.substring(0, currentPositionZero -1) + '0' + state.charAt(currentPositionZero - 1) + state.substring(currentPositionZero + 1);
                break;
            case DOWN:
                newState = state.substring(0, currentPositionZero) + state.charAt(currentPositionZero + 3) + state.substring(currentPositionZero + 1, currentPositionZero + 3) + '0';
                if (currentPositionZero != 5) newState += state.substring(currentPositionZero + 4);
                break;
        }
        return newState;
    }

    public static int getNodes() {
        return nodes;
    }

    public void setState(String state) {
        this.state = state;
    }

    public void setChildrenExpanded(boolean childrenExpanded) {
        this.childrenExpanded = childrenExpanded;
    }

    public boolean isChildrenExpanded() {
        return childrenExpanded;
    }

    public void setParent(NodeA parent) {
        this.parent = parent;
    }

    public void setAction(ActionA action) {
        this.action = action;
    }

    public void setDepth(int depth) {
        this.depth = depth;
    }

    public void setAvailableActions(ActionA[] availableActions) {
        this.availableActions = availableActions;
    }

    public void setVisited(ArrayList<String> visited) {
        this.visited = visited;
    }

    public static void setNodes(int nodes) {
        NodeA.nodes = nodes;
    }

    public String getState() {
        return state;
    }

    public NodeA getParent() {
        return parent;
    }

    public ActionA getAction() {
        return action;
    }

    public int getDepth() {
        return depth;
    }

    public ActionA[] getAvailableActions() {
        return availableActions;
    }

    public ArrayList<String> getVisited() {
        return visited;
    }

    public static ActionA[] generateAvailableActions(String state){
        int availableMoves = 0;
        int currentPositionZero = state.indexOf('0');
        if (currentPositionZero > 2) availableMoves += 1;
        if ((currentPositionZero+1) % 3 != 0) availableMoves += 2;
        if (currentPositionZero < 6) availableMoves += 4;
        if (currentPositionZero % 3 != 0) availableMoves += 8;
        switch (availableMoves){
            case 3:
                return new ActionA[]{ActionA.UP, ActionA.RIGHT};
            case 6:
                return new ActionA[]{ActionA.RIGHT, ActionA.DOWN};
            case 7:
                return new ActionA[]{ActionA.UP, ActionA.RIGHT, ActionA.DOWN};
            case 9:
                return new ActionA[]{ActionA.UP, ActionA.LEFT};
            case 11:
                return new ActionA[]{ActionA.UP, ActionA.RIGHT, ActionA.LEFT};
            case 12:
                return new ActionA[]{ActionA.DOWN, ActionA.LEFT};
            case 13:
                return new ActionA[]{ActionA.UP, ActionA.DOWN, ActionA.LEFT};
            case 14:
                return new ActionA[]{ActionA.RIGHT, ActionA.DOWN, ActionA.LEFT};
            case 15:
                return new ActionA[]{ActionA.UP, ActionA.RIGHT, ActionA.DOWN, ActionA.LEFT};
            default:
                return null;
        }
    }

    public void setA(int a) {
        A = a;
    }

    public int getA() {
        return A;
    }

    public static int getHeuristic(String state){
        int A1 = 0;
        int A2 = 0;
        for (int i=1; i<9; ++i){
            if (state.indexOf(String.valueOf(i)) != i) A1++;
            A2 += Math.abs(state.indexOf(String.valueOf(i)) % 3 - i % 3) + Math.abs(state.indexOf(String.valueOf(i)) / 3 - i / 3);
        }
        return Math.max(A1, A2);
    }

    @Override
    public String toString() {
        return this.state;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        NodeA node = (NodeA) o;
        return ((NodeA) o).state.equals(this.state);
    }

    @Override
    public int hashCode() {
        return Integer.parseInt(this.toString());
    }
}
