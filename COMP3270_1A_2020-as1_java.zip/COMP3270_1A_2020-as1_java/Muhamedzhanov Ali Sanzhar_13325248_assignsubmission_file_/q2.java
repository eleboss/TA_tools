import java.util.ArrayList;

public class q3 {
    public static void main(String[] args) {
        Node2 start = new Node2(3, 0, 3, 0, false,null, null, 0, new ArrayList<String>());
        start.visited.add(start.toString());
        int maxDepth = 0;
        while (true){
            boolean result = Node2.checkNode(maxDepth, start);
            if (result) return;
            System.out.println(maxDepth);
            maxDepth++;
            if (Node2.nodes == 1_000_000) System.out.println("Reached 1000000 nodes, no more will be created");
            Node2.nodes = 1;
        }
    }
}

enum Act{
    mL,
    mLL,
    mR,
    mRR,
    cL,
    cLL,
    cR,
    cRR,
    mcL,
    mcR
}

class Node2{
    int mL;
    int mR;
    int cL;
    int cR;
    boolean boat;
    Node2 parent;
    Act action;
    int depth;
    ArrayList<String> visited;
    static int nodes;

    public Node2(int mL, int mR, int cL, int cR, boolean boat, Node2 parent, Act action, int depth, ArrayList<String> visited) {
        this.mL = mL;
        this.mR = mR;
        this.cL = cL;
        this.cR = cR;
        this.boat = boat;
        this.parent = parent;
        this.action = action;
        this.depth = depth;
        this.visited = visited;

    }

    public static boolean actionValid(Act action, int mL, int mR, int cL, int cR, boolean boat){
        switch (action){
            case mL:
                return boat && mR - 1 >= 0 && (mR - 1 >= cR || mR - 1 == 0) && mL + 1 >= cL;
            case cR:
                return !boat && cL - 1 >= 0 && (mR - 1 >= cR || mR == 0) && (mL >= cL - 1 || mL == 0);
            case mLL:
                return boat && mR - 2 >= 0 && (mR - 2 >= cR || mR - 2 == 0) && mL + 2 >= cL;
            case cRR:
                return !boat && cL - 2 >= 0 && (mR - 2 >= cR || mR == 0) && (mL >= cL - 2 || mL == 0);
            case mR:
                return !boat && mL - 1 >= 0 && (mL - 1 >= cL || mL - 1 == 0) && mR + 1 >= cR;
            case cL:
                return boat && cR - 1 >= 0 && (mL >= cL + 1 || mL == 0) && (mR >= cR - 1 || mR == 0);
            case mRR:
                return !boat && mL - 2 >= 0 && (mL - 2 >= cL || mL - 2 == 0) && mR + 2 >= cR;
            case cLL:
                return boat && cR - 2 >= 0 && (mL - 2 >= cL || mL == 0) && (mR >= cR - 2 || mR == 0);
            case mcL:
                return boat && mR - 1 >= 0 && cR - 1 >= 0 && mL >= cL;
            case mcR:
                return !boat && mL - 1 >= 0 && cL - 1 >= 0 && mR >= cR;
            default:
                return false;
        }
    }

    public static Node2 stateAfterAction(Node2 parent, Act action){
        switch (action){
            case mL:
                return new Node2(parent.mL + 1, parent.mR - 1, parent.cL, parent.cR, false, parent, action, parent.depth + 1, new ArrayList<>(parent.visited));
            case cR:
                return new Node2(parent.mL, parent.mR, parent.cL - 1, parent.cR + 1, true, parent, action, parent.depth + 1, new ArrayList<>(parent.visited));
            case mLL:
                return new Node2(parent.mL + 2, parent.mR - 2, parent.cL, parent.cR, false, parent, action, parent.depth + 1, new ArrayList<>(parent.visited));
            case cRR:
                return new Node2(parent.mL, parent.mR, parent.cL - 2, parent.cR + 2, true, parent, action, parent.depth + 1, new ArrayList<>(parent.visited));
            case mR:
                return new Node2(parent.mL - 1, parent.mR + 1, parent.cL, parent.cR, true, parent, action, parent.depth + 1, new ArrayList<>(parent.visited));
            case cL:
                return new Node2(parent.mL, parent.mR, parent.cL + 1, parent.cR - 1, false, parent, action, parent.depth + 1, new ArrayList<>(parent.visited));
            case mRR:
                return new Node2(parent.mL - 2, parent.mR + 2, parent.cL, parent.cR, true, parent, action, parent.depth + 1, new ArrayList<>(parent.visited));
            case cLL:
                return new Node2(parent.mL, parent.mR, parent.cL + 2, parent.cR - 2, false, parent, action, parent.depth + 1, new ArrayList<>(parent.visited));
            case mcL:
                return new Node2(parent.mL + 1, parent.mR - 1, parent.cL + 1, parent.cR - 1, false, parent, action, parent.depth + 1, new ArrayList<>(parent.visited));
            case mcR:
                return new Node2(parent.mL - 1, parent.mR + 1, parent.cL - 1, parent.cR + 1, true, parent, action, parent.depth + 1, new ArrayList<>(parent.visited));
            default:
                return null;
        }
    }

    public static Act[] getAvailableActions(Node2 node){
        ArrayList<Act> actions = new ArrayList<>();
        for (Act action: Act.values()){
            if (actionValid(action, node.mL, node.mR, node.cL, node.cR, node.boat)) actions.add(action);
        }
        Act[] arr = new Act[actions.size()];
        arr = actions.toArray(arr);
        return arr;
    }

    @Override
    public String toString() {
        return action != null ? "" + action + "\n" + mL + mR + cL + cR + " " + boat : "" + mL + mR + cL + cR + " " + boat;
    }

    public static boolean checkNode(int maxDepth, Node2 parent) {
        if (parent.toString().contains("0303 true")) {
            System.out.println();
            System.out.println("Solution was found, it has " + (parent.visited.size() + 1) + " moves and detailed steps are below: ");
            for(String visited: parent.visited){
                System.out.println(visited);
            }
            return true;
        }
        else
        if (parent.depth == maxDepth) {
            return false;
        }
        else {
            for (Act action: getAvailableActions(parent)){
                if (Node2.nodes == 1_000_000) {
                    return false;
                }
                Node2 child = Node2.stateAfterAction(parent, action);
                assert child != null;
                if (!parent.visited.contains(child.toString())) {
                    child.visited.add(child.toString());
                    boolean result = Node2.checkNode(maxDepth, child);
                    if (result) {
                        return true;
                    } else if (Node2.nodes == 1_000_000) return false;
                }
            }
        }
        return false;
    }
}
