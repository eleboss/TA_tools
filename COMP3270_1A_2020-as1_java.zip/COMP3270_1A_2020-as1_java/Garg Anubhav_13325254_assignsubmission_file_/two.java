import java.util.*;

class CanMis
{
	private int canLeft;
	private int canRight;
	private int misLeft;
	private int misRight;
	private boolean boatPos; //false means left
	private CanMis parent;
	
	public CanMis(int canLeft, int canRight, int misLeft, int misRight, boolean boatPos)
	{
		this.canLeft = canLeft;
		this.canRight = canRight;
		this.misLeft = misLeft;
		this.misRight = misRight;
		this.boatPos = boatPos;
	}
	
	public boolean reachedGoal()
	{
		return canLeft == 0 && misLeft == 0;
	}
	
	public boolean isPossible()
	{
		if(misLeft >= 0 && misRight >=0 && canLeft >= 0 && canRight >=0)
		{
			if((misLeft == 0 || misLeft >= canLeft)&&(misRight == 0 || misRight >= canRight))
			{
				return true;
			}
		}
		return false;
	}
	
	public ArrayList<CanMis> expand()
	{
		ArrayList <CanMis> list = new ArrayList<CanMis>();
		
		if(boatPos == false)// meaning left
		{
			CanMis temp = new CanMis(canLeft, canRight, misLeft - 2,  misRight + 2, true);
			testing(list, temp);

			temp = new CanMis(canLeft - 2, canRight + 2, misLeft,  misRight, true);
			testing(list, temp);

			temp = new CanMis(canLeft - 1, canRight + 1, misLeft - 1,  misRight + 1, true);
			testing(list, temp);

			temp = new CanMis(canLeft, canRight, misLeft - 1,  misRight + 1, true);
			testing(list, temp);
			
			temp = new CanMis(canLeft - 1, canRight + 1, misLeft,  misRight, true);
			testing(list, temp);
		} 
		else
		{
			CanMis temp = new CanMis(canLeft, canRight, misLeft + 2,  misRight - 2, false);
			testing(list, temp);

			temp = new CanMis(canLeft + 2, canRight - 2, misLeft,  misRight, false);
			testing(list, temp);

			temp = new CanMis(canLeft + 1, canRight - 1, misLeft + 1,  misRight - 1, false);
			testing(list, temp);

			temp = new CanMis(canLeft, canRight, misLeft + 1,  misRight - 1, false);
			testing(list, temp);
			
			temp = new CanMis(canLeft + 1, canRight - 1, misLeft,  misRight, false);
			testing(list, temp);
		}

		return list;
	}
	
	public void testing(ArrayList<CanMis> list, CanMis temp)
	{
		if(temp.isPossible())
		{
			temp.setParent(this);
			list.add(temp);
		}
	}
	
	public CanMis getParent()
	{
		return this.parent;
	}
	public void setParent(CanMis parent)
	{
		this.parent = parent;
	}
	
	public String toString()
	{
		if(boatPos == false)
		{
			return "("+canLeft+", " + misLeft +", " + canRight + ", " + misRight + ", L)";
		}
		else
		{
			return "(" + canLeft + ", " + misLeft + ", " + canRight + ", " + misRight + ", R)";
		}

	}
}

public class two {

    public static void main(String [] args)
    {
        CanMis number1 = new CanMis(3,0,3,0,false);
        BFS(number1);
    }

    public static CanMis BFS(CanMis start)
    {
        if(start.reachedGoal())
        {
            return start;
        }

        Queue<CanMis> open = new LinkedList<CanMis>();
        Set<CanMis> closed = new HashSet<CanMis>();
		open.add(start);
		
        while(true)
        {
            if(open.isEmpty())
            {
                return null;
            }

            CanMis current = open.poll();
            closed.add(current);

            ArrayList<CanMis> children = current.expand();

            for(CanMis child : children)
            {
                if(!closed.contains(child) || !open.contains(child))
                {
                    if(child.reachedGoal())
                    {
						tracePath(child);
                        return child;
                    }
                    
                    open.add(child);
                }
            }
        }
    }
    
    public static void tracePath(CanMis sol)
    {
		if(sol == null)
			System.out.println("No solution found");
		else
		{
			ArrayList<CanMis> ans = new ArrayList<CanMis>();
			CanMis current = sol;

			while(sol!=null)
			{
				ans.add(sol);
				sol = sol.getParent();
			}
			
			int depth = ans.size();
			Collections.reverse(ans);
			
			System.out.println("#Cannibals Left, #Missionaries Left, #Cannibals Right, #Missionaries Right, Boat Position\n");

			for(int i = 0; i < depth; i++)
			{
				current = ans.get(i);
				if(current.reachedGoal())
					System.out.println(current.toString() + " -> Reached!");
				else
					System.out.println(current.toString());
			}
			System.out.println("\nNumber of moves = " + (depth-1));
		}
	}
}

