import java.util.*; 
import java.lang.*;

class board
{
	int[] puzzle = new int[9]; // Create an ArrayList object
	int [] target = {0,1,2,3,4,5,6,7,8};

	board parent;
	int cost = 0;
	int depth = 0;

	ArrayList<board> children = new ArrayList<board>();
	
	public board(){};
	public board(int [] p)
	{
		for(int i = 0; i<9; i++)
		{
			this.puzzle[i] = p[i];
		}
		children = new ArrayList<board>();
	}
	
	public int getDepth()
	{
		return this.depth;
	}
	
	public void setDepth(int depth)
	{
		this.depth = depth;
	}
	
	public ArrayList<board> getChildren()
	{
		return this.children;
	}
	
	public boolean checkSolved()
	{
		return Arrays.equals(puzzle,target);
	}
	
	public int findZero()
	{
		for(int i = 0; i < 9; i++)
		{
			if(puzzle[i] == 0)
				return i;
		}
		return -1;
	}
	
	public int getCost()
	{
		return this.cost;
	}
	
	public void swap(int i, int j) 
	{
		int [] temp = puzzle.clone();
		temp[i] = (temp[i] + temp[j]) - (temp[j] = temp[i]);
		board child = new board(temp);
		
		child.parent = this;
		children.add(child);
	}
	
	public void expandBoard()
	{
		moveLeft();
		moveUp();
		moveRight();
		moveDown();
	}

	public void moveLeft()
	{
		int zeroIndex = findZero();
		if((zeroIndex)%3 >0)
		{
			swap(zeroIndex, zeroIndex-1);
		}		
	}
	
	public void moveRight()
	{
		int zeroIndex = findZero();
		if((zeroIndex + 1)%3 !=0)
		{
			swap(zeroIndex, zeroIndex+1);
		}

	}
	
	public void moveUp()
	{
		int zeroIndex = findZero();
		
		if((zeroIndex - 3) >= 0 && (zeroIndex - 3) <= 8)
		{
			swap(zeroIndex, zeroIndex-3);
		}
	}
	
	public void moveDown()
	{
		int zeroIndex = findZero();
		
		if((zeroIndex + 3) >= 0 && (zeroIndex + 3) <= 8)
		{
			swap(zeroIndex, zeroIndex+3);
		}
		
	}
	
	public String printPuzzle()
	{
		String x = "";
		for(int i = 0; i<9;i++)
		{
			if(i %3 == 0)
				x += "\n";
			x += (puzzle[i] + " ");
		}
		x += "\n";
		return x;
	}
	
	// ALL CODES FOR A STAR

	public int hammingDistance()
	{
		int count = 0;
		for(int i = 0; i < 9; i++)
		{
			if (puzzle[i] == 0)
				continue;
			if(puzzle[i] != target[i])
				count++;
		}
		return count;
	}
	public int manhattanDistance()
	{
		int sum = 0;
		for (int i = 0; i < 9; i++)
		{
			int num = this.puzzle[i];
			if(num!=0)
				sum += Math.abs((num)%3 - i%3) + Math.abs(Math.floor((num)/3) - Math.floor(i/3));
		}
		return sum;
	}
	
	public int fValue(char c)
	{
		if(c == 'h')
			this.cost = hammingDistance() + depth;
		else if(c == 'm')
			this.cost = manhattanDistance() + depth;

		return this.cost;
	}

	public int compare(board b)
	{
		if(this.cost < b.getCost() )
			return -1;
		else if (this.cost > b.getCost())
			return 1;
		else
			return 0;
	}	
}

public class oneB
{
	static int [] target = {0,1,2,3,4,5,6,7,8};
	static ArrayList<board> visited = new ArrayList<board>();
	
	public static void main(String [] args)
	{
		Scanner sc=new Scanner(System.in);  
		System.out.print("Please put the board in one row as a string: ");
		String input = sc.nextLine();
		
		int [] puzzle1 = new int[9];
		for (int i = 0; i < 9; i++)
		{
			puzzle1[i] = input.charAt(i) - '0';
		}
		board b = new board(puzzle1);
		
		System.out.println("Type 'm' for Manhattan distance or 'h' for Hamming distance");
		System.out.print("Please put the board in one row as a string: ");
		char option = sc.nextLine().charAt(0);
		
		switch(option) {
			case 'm':
				aStar(b, 'm');
				break; // optional
			case 'h':
				aStar(b, 'h');
				break; // optional
			default : 
				System.out.println("Invalid option");
		}
	}
	
	public static void aStar(board start, char option)
	{
		PriorityQueue<board> open = new PriorityQueue<board>(new boardComparator());	
		ArrayList<board> closed = new ArrayList<board>(); 
		
		open.clear(); 
		closed.clear();
		
		open.add(start);
		start.setDepth(0);
		
		while(!open.isEmpty())
		{
			board best = open.remove(); //get first element from pq 
			
			
			if(best.checkSolved())
			{
				tracePath(best);
				break;
			}
			
			best.expandBoard();
			closed.add(best);
			for(int i = 0; i < best.children.size(); i++)
			{
				if(!pqContains(best.children.get(i), closed))
				{
					best.children.get(i).setDepth(best.children.get(i).parent.getDepth() + 1);
					best.children.get(i).fValue(option);//m//updates the cost
					open.add(best.children.get(i));

				}
			}
		}

	}
	
	public static void tracePath(board node)
	{
		ArrayList<board> path = new ArrayList<board>();

		int [] btarget = {0,1,2,3,4,5,6,7,8};
		board t = new board(btarget);
		
		while(node.parent!=null)
		{
			path.add(node);
			node = node.parent;
		}

		Collections.reverse(path);
		
		System.out.println("Found a path!");

		for(int i = 0; i < path.size(); i++)
		{
			System.out.println(path.get(i).printPuzzle());
		}
		
		System.out.println(t.printPuzzle());
		
		System.out.println("Number of moves: " + path.size());
	}
	
	public static boolean pqContains(board node, ArrayList<board> closed)
	{
		for(board it:closed)
		{
			if(Arrays.equals(it.puzzle,node.puzzle))
				return true;
		}
		return false;
	}
}

class boardComparator implements Comparator<board>{ 
	public int compare(board b1, board b2) { 
		if (b1.cost > b2.cost) 
			return 1; 
		else if (b1.cost < b2.cost) 
			return -1; 
		return 0; 
	} 
} 
  

