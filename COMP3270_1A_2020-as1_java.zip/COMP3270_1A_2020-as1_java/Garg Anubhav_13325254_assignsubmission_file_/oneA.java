import java.util.Arrays; 
import java.util.Iterator;
import java.util.*; 

class board
{
	int[] puzzle = new int[9]; // Create an ArrayList object
	int [] target = {0,1,2,3,4,5,6,7,8};

	board parent;
	ArrayList<board> children = new ArrayList<board>();
	
	public board(){};
	public board(int [] p)
	{
		for(int i = 0; i<9; i++)
		{
			this.puzzle[i] = p[i];
		}
		children = new ArrayList<board>();
	}

	public ArrayList<board> getChildren()
	{
		return this.children;
	}
	
	public boolean checkSolved()
	{
		return Arrays.equals(puzzle,target);
	}
	
	public int findZero()
	{
		for(int i = 0; i < 9; i++)
		{
			if(puzzle[i] == 0)
				return i;
		}
		return -1;
	}
		
	public void swap(int i, int j) 
	{
		int [] temp = puzzle.clone();
		temp[i] = (temp[i] + temp[j]) - (temp[j] = temp[i]);
		board child = new board(temp);
		
		child.parent = this;
		children.add(child);
	}
	
	public void expandBoard()
	{
		moveLeft();
		moveUp();
		moveRight();
		moveDown();
	}

	public void moveLeft()
	{
		int zeroIndex = findZero();
		if((zeroIndex)%3 >0)
		{
			swap(zeroIndex, zeroIndex-1);
		}		
	}
	
	public void moveRight()
	{
		int zeroIndex = findZero();
		if((zeroIndex + 1)%3 !=0)
		{
			swap(zeroIndex, zeroIndex+1);
		}

	}
	
	public void moveUp()
	{
		int zeroIndex = findZero();
		
		if((zeroIndex - 3) >= 0 && (zeroIndex - 3) <= 8)
		{
			swap(zeroIndex, zeroIndex-3);
		}
	}
	
	public void moveDown()
	{
		int zeroIndex = findZero();
		
		if((zeroIndex + 3) >= 0 && (zeroIndex + 3) <= 8)
		{
			swap(zeroIndex, zeroIndex+3);
		}
		
	}
	
	public String printPuzzle()
	{
		String x = "";
		for(int i = 0; i<9;i++)
		{
			if(i %3 == 0)
				x += "\n";
			x += (puzzle[i] + " ");
		}
		x += "\n";
		return x;
	}
}

public class oneA
{
	static int [] target = {0,1,2,3,4,5,6,7,8};
	static boolean bottomReached = false;
	static int nodeCounter = 0;
	static ArrayList<board> visited = new ArrayList<board>();

	public static void main(String [] args)
	{
		Scanner sc=new Scanner(System.in);  
		System.out.print("Please put the board in one row as a string: ");
		String input = sc.nextLine();
		
		int [] puzzle1 = new int[9];
		for (int i = 0; i < 9; i++)
		{
			puzzle1[i] = input.charAt(i) - '0';
		}
		board b = new board(puzzle1);
		
		IDS(b);
	}
	public static board IDS(board start) {
        int depth = 0;
        while (nodeCounter < 1000000) {
            board result = IDS(start, 0, depth);

            if (result != null) {
				tracePath(result);
                return result;
            }
            depth++;
            //System.out.println("Checking depth = " + depth);
        }
        return null;
    }
	
    private static board IDS(board node, int currentDepth, int maxDepth) {
        if(nodeCounter >= 1000000)
        {
			System.out.println("Reached 1 million node limit");
			System.exit(0);
		}
		nodeCounter++;
		//System.out.println(nodeCounter);
		    
        if(node == null)
			return null;
		
        if (node.checkSolved()) {
			System.out.println("Found the node we're looking for!");
            return node;
        }
        
        if(currentDepth >= maxDepth)
			return null;
        else
        {
			node.expandBoard();
			for (int i = 0; i < node.children.size(); i++) {
				board result = IDS(node.children.get(i), ++currentDepth, maxDepth);
				if (result != null && result.checkSolved()) {
					return result;
				}
			}
		}        
        return null;
    }
	
	
	public static boolean contains(board node)
	{
		for(int i = 0; i < visited.size(); i++)
		{
			if(Arrays.equals(visited.get(i).puzzle,node.puzzle))
			{
				return true;
			}
		}
		return false;
	}
	
	public static void tracePath(board node)
	{
		ArrayList<board> path = new ArrayList<board>();

		int [] btarget = {0,1,2,3,4,5,6,7,8};
		board t = new board(btarget);
		
		while(node!=null)
		{
			path.add(node);
			node = node.parent;
		}

		Collections.reverse(path);

		for(int i = 0; i < path.size(); i++)
		{
			System.out.println(path.get(i).printPuzzle());
		}
				
		System.out.println("Number of moves: " + (path.size()-1));
	}
	
}
  


